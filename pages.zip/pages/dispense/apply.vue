<template>
    <view class="page">
  
      <!-- 状态栏占位（适配刘海等）-->
      <view class="safe-top" />
   
    
  <view style="padding: 20rpx;">

  
      <!-- 页面内容 -->
      <scroll-view class="body body-scroll" scrollY>
  
        <!-- 指定药品 卡片 -->
        <view class="card">
          <view class="card-title">指定药品</view>
          <view 
            class="card-body" 
            v-for="(item, index) in cartItems" 
            :key="item.id"
            :style="{marginBottom: index < cartItems.length - 1 ? '20rpx' : '0'}"
          >
            <view class="med-left">
              <image class="med-thumb" :src="item.image" mode="aspectFill" />
              <view class="med-qty" v-if="item.quantity">×{{ item.quantity }}</view>
            </view>
  
            <view class="med-right">
              <view class="med-name">{{ item.name }}</view>
              <view class="med-price">¥{{ item.price.toFixed(2) }}</view>
            </view>
          </view>
          <view class="modify-wrapper">
            <view class="modify" @click="onModify">修改</view>
          </view>
        </view>
  
        <!-- 就诊人信息 -->
        <view class="section">
          <view class="section-title">就诊人信息</view>
  
          <view class="patient-row">
            <view class="label"><text class="required">*</text> 就诊人</view>
  
            <view class="patients">
              <view
                class="patient-chip"
                v-for="p in patients"
                :key="p.id"
                :class="{active: selectedPatient && selectedPatient.id === p.id}"
                @click="selectPatient(p)"
              >
                {{ p.name }}
              </view>
  
              <view class="patient-add" @click="onAddPatient">＋ 添加就诊人</view>
            </view>
          </view>
        </view>
  
        <!-- 占位（让页面更接近你示意图的空白） -->
        <view style="height: 40vh"></view>
  
      </scroll-view>
    </view>
      <!-- 底部固定提交栏 -->
      <view class="footer">
        <view class="footer-left">
          <view class="icon-bag">
            <uni-icons type="cart" size="24" color="#4a90e2"></uni-icons>
            <text class="badge" v-if="totalQuantity > 0">{{ totalQuantity }}</text>
          </view>
          <view class="total">
            <text class="price">¥{{ totalPrice.toFixed(2) }}</text>
            <text class="note"> 不含复诊费，实际金额以结算为准</text>
          </view>
        </view>
  
        <button class="submit-btn" type="primary" @click="onSubmit">提&nbsp;交</button>
      </view>
  
    </view>
  </template>
  
<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { STORAGE_KEY_USER_REGISTER } from '@/utils/storage.js'
import { loadCartItems, calculateTotalPrice, calculateTotalQuantity } from '@/utils/cart.js'
  
  const cartItems = ref([]) // 购物车商品列表
  const productsData = ref(null) // 产品数据
  const categories = ref([]) // 分类列表
  
  const patients = ref([])
  const selectedPatient = ref(null)
  
  // 计算总价格
  const totalPrice = computed(() => {
    return calculateTotalPrice(cartItems.value)
  })
  
  // 计算总数量
  const totalQuantity = computed(() => {
    return calculateTotalQuantity(cartItems.value)
  })
  
  // 从 storage 加载就诊人信息
  onMounted(() => {
    loadPatientsFromStorage()
    loadProducts()
  })
  
  const loadPatientsFromStorage = () => {
    try {
      const userRegisterInfo = uni.getStorageSync(STORAGE_KEY_USER_REGISTER)
      if (userRegisterInfo && userRegisterInfo.realName) {
        // 将注册信息作为就诊人
        const patient = {
          id: 1,
          name: userRegisterInfo.realName
        }
        patients.value = [patient]
        selectedPatient.value = patient
      } else {
        // 如果没有注册信息，使用默认数据
        patients.value = [
          { id: 1, name: '张子扬' },
          { id: 2, name: '李小花' }
        ]
        selectedPatient.value = patients.value[0] || null
      }
    } catch (e) {
      console.error('加载就诊人信息失败:', e)
      // 使用默认数据
      patients.value = [
        { id: 1, name: '张子扬' },
        { id: 2, name: '李小花' }
      ]
      selectedPatient.value = patients.value[0] || null
    }
  }
  
  // 加载产品数据
  const loadProducts = () => {
    uni.request({
      url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
      method: 'GET',
      success: (res) => {
        if (res.data && res.data.categories) {
          productsData.value = res.data
          categories.value = res.data.categories
          // 产品数据加载完成后，加载购物车数据
          loadCartData()
        }
      },
      fail: (err) => {
        console.error('加载产品数据失败:', err)
        // 如果请求失败，使用本地数据
        loadLocalData()
        // 本地数据加载完成后，加载购物车数据
        loadCartData()
      }
    })
  }
  
  // 加载本地产品数据（备用）
  const loadLocalData = () => {
    const noticeText = '开方前需要先了解该药物是否适合您，请如实填写，以便判断该药物是否适合您\n\n【适应人群】皮肤干燥、口干咽干、容易口渴大便不稀薄的人群\n\n【注意事项】:糖尿病患者及有高血压、心脏病、肝病、肾病等慢性病严重者应在医师指导下用药。'
    
    categories.value = [
      {
        id: 'zhou',
        name: '养生粥',
        products: [
          {
            id: 'zhou1',
            name: '养生粥系列一',
            description: '精选优质食材，营养丰富，适合日常养生',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png',
            unit: '1帖',
            price: 28.00,
            notice: noticeText
          },
          {
            id: 'zhou2',
            name: '养生粥系列二',
            description: '温补养胃，适合脾胃虚弱者',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png',
            unit: '1帖',
            price: 32.00,
            notice: noticeText
          },
          {
            id: 'zhou3',
            name: '养生粥系列三',
            description: '滋阴润燥，适合秋冬季节',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png',
            unit: '1帖',
            price: 30.00,
            notice: noticeText
          }
        ]
      },
      {
        id: 'gaoyao',
        name: '辽派滋膏',
        products: [
          {
            id: 'gaoyao1',
            name: '辽派滋膏系列一',
            description: '传统工艺，滋补养生，适合体虚者',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png',
            unit: '1帖',
            price: 88.00,
            notice: noticeText
          },
          {
            id: 'gaoyao2',
            name: '辽派滋膏系列二',
            description: '精选药材，补气养血，增强体质',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png',
            unit: '1帖',
            price: 95.00,
            notice: noticeText
          }
        ]
      }
    ]
  }
  
  // 从 storage 加载购物车数据
  const loadCartData = () => {
    try {
      // 使用统一的工具函数加载购物车数据
      cartItems.value = loadCartItems(categories.value)
      
      // 如果没有商品，提示用户
      if (cartItems.value.length === 0) {
        uni.showToast({
          title: '购物车为空',
          icon: 'none'
        })
        // 延迟返回上一页
        setTimeout(() => {
          uni.navigateBack()
        }, 1500)
      }
      
      console.log('购物车数据已加载:', cartItems.value.length, '件商品')
    } catch (e) {
      console.error('加载购物车数据失败:', e)
      uni.showToast({
        title: '加载购物车失败',
        icon: 'none'
      })
    }
  }
  
  // 底部栏高度（参考列表页面的 120rpx）
  const footerHeight = 120
  
  const onClose = () => {
    // 小程序返回/关闭
    uni.navigateBack({ delta: 1 })
  }
  
  const onModify = () => {
    // 返回商品列表页面进行修改
    uni.navigateBack()
  }
  
  const selectPatient = (p) => {
    selectedPatient.value = p
  }
  
  const onAddPatient = () => {
    // 弹出添加（示例用模态，实际可跳转到添加页并回调）
    uni.showModal({
      title: '添加就诊人',
      content: '示例：是否新增一个测试就诊人？',
      success: (res) => {
        if (res.confirm) {
          // 简单示例：新增一个虚拟就诊人
          const newId = patients.value.length + 1
          const newP = { id: newId, name: '新就诊人' + newId }
          patients.value.push(newP)
          selectedPatient.value = newP
          uni.showToast({ title: '已添加就诊人', icon: 'success' })
        }
      }
    })
  }
  
  const onSubmit = () => {
    if (!selectedPatient.value) {
      uni.showToast({ title: '请先选择就诊人', icon: 'none' })
      return
    }
  
    // 跳转到在线复诊页面
    uni.navigateTo({
      url: '/pages/dispense/consultation'
    })
  }
  </script>
  
  <style scoped>
  /* Safe area 顶部填充（适配状态栏高度）*/
  .safe-top {
    height: env(safe-area-inset-top);
    background: #fff;
  }
  
  /* 整体背景 */
  .page {
    background: #f6f7fb;
    min-height: 100vh;
  }
  
  /* 白色导航栏 */
  .nav-bar {
    height: 88rpx;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    padding: 0 20rpx;
    border-bottom: 1rpx solid #eee;
  }
  .nav-left, .nav-right {
    position: absolute;
    top: 0;
    bottom: 0;
    width: 120rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #333;
    font-size: 36rpx;
  }
  .nav-left { left: 0; }
  .nav-right { right: 0; }
  .nav-title {
    font-size: 34rpx;
    font-weight: 600;
  }
  
  /* 页面滚动区 */
  .body-scroll {
    padding-bottom: calc(120rpx + env(safe-area-inset-bottom));
  }
  
  /* 卡片 */
  .card {
    background: #fff;
    border-radius: 8rpx;
    padding: 20rpx;
    margin-bottom: 20rpx;
    box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.03);
  }
  .card-title {
    font-size: 30rpx;
    font-weight: 600;
    text-align: center;
    margin-bottom: 10rpx;
    color: #333;
  }
  .card-body {
    display: flex;
    align-items: center;
    position: relative;
    padding-bottom: 20rpx;
    border-bottom: 1rpx solid #f0f0f0;
  }
  .card-body:last-of-type {
    border-bottom: none;
    padding-bottom: 0;
  }
  .modify-wrapper {
    text-align: right;
    margin-top: 10rpx;
    padding-top: 10rpx;
    border-top: 1rpx solid #f0f0f0;
  }
  .med-left {
    position: relative;
    width: 160rpx;
    height: 160rpx;
    margin-right: 20rpx;
  }
  .med-thumb {
    width: 100%;
    height: 100%;
    border-radius: 8rpx;
    background: #eee;
  }
  .med-qty {
    position: absolute;
    right: -10rpx;
    top: -10rpx;
    background: #fff;
    color: #333;
    padding: 6rpx 12rpx;
    border-radius: 16rpx;
    font-size: 26rpx;
    border: 1rpx solid #ddd;
  }
  
  .med-right {
    flex: 1;
  }
  .med-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    margin-bottom: 12rpx;
  }
  .med-price {
    color: #e64340;
    font-size: 28rpx;
  }
  
  .modify {
    position: absolute;
    right: 14rpx;
    top: 14rpx;
    color: #4a90e2;
    font-size: 28rpx;
  }
  
  /* section */
  .section {
    margin-top: 20rpx;
    background: #fff;
    padding: 24rpx;
    border-radius: 8rpx;
    box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.03);
  }
  .section-title {
    font-size: 30rpx;
    font-weight: 700;
    text-align: center;
    margin-bottom: 18rpx;
  }
  .patient-row {
    display: flex;
    flex-direction: column;
  }
  .label {
    font-size: 26rpx;
    color: #666;
    margin-bottom: 18rpx;
  }
  .required { color: #e64340; margin-right: 6rpx; }
  
  /* 就诊人 chips */
  .patients {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex-wrap: wrap;
  }
  .patient-chip {
    padding: 12rpx 28rpx;
    border-radius: 36rpx;
    background: #f4f7ff;
    color: #4a90e2;
    font-size: 26rpx;
    border: 1rpx solid transparent;
  }
  .patient-chip.active {
    background: #2a82e4;
    color: #fff;
    border-color: rgba(0,0,0,0.06);
    box-shadow: 0 2rpx 6rpx rgba(42,130,228,0.12);
  }
  .patient-add {
    padding: 12rpx 18rpx;
    color: #3e86e4;
    font-size: 26rpx;
  }
  
  /* footer 固定底部 */
  .footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    min-height: 120rpx;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18rpx 24rpx;
    padding-top: 0;
    padding-bottom: calc(18rpx + env(safe-area-inset-bottom));
    box-shadow: 0 -6rpx 18rpx rgba(0,0,0,0.06);
    z-index: 100;
  }
  
  /* footer 左侧包裹 */
  .footer-left {
    display: flex;
    align-items: center;
    gap: 12rpx;
  }
  .icon-bag {
    width: 72rpx;
    height: 72rpx;
    border-radius: 12rpx;
    background: #f0f6ff;
    display:flex;
    align-items:center;
    justify-content:center;
    position: relative;
  }
  .badge {
    position: absolute;
    top: -8rpx;
    right: -8rpx;
    background: #ff4d4f;
    color: #fff;
    padding: 4rpx 8rpx;
    border-radius: 16rpx;
    font-size: 22rpx;
  }
  .total .price {
    font-size: 30rpx;
    color: #e64340;
    font-weight: 600;
  }
  .total .note {
    display: block;
    font-size: 22rpx;
    color: #999;
  }
  
  /* 提交按钮 */
  .submit-btn {
    margin: 0;
    background: #2a82e4;
    color: #fff;
    padding: 0 35rpx;
    border-radius: 50rpx;
    font-size: 30rpx;
    border: none;
  }
  </style>
  