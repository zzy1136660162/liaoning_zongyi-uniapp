<template>
    <view class="page">
      <!-- 顶部导航用原生小程序导航栏即可，这里不重复写 -->
  
      <!-- 订单卡片 -->
      <view class="order-card">
        <!-- 上半部分：标题 + 金额 + 状态 -->
        <view class="order-header">
          <view class="order-header-left">
            <view class="title-row">
              <view class="icon-circle">
                <text class="icon-plus">＋</text>
              </view>
              <text class="title-text">药品处方</text>
            </view>
            <text class="amount-text">¥{{ totalAmount.toFixed(2) }}</text>
          </view>
  
          <view class="order-header-right">
            <text class="status-text">{{ order.statusText }}</text>
            <text class="time-text">{{ formatDateTime(order.time) }}</text>
          </view>
        </view>
  
        <view class="divider"></view>
  
        <!-- 信息区域 -->
        <view class="info-row" v-for="item in infoList" :key="item.label">
          <text class="info-label">{{ item.label }}</text>
          <text class="info-value">{{ item.value }}</text>
        </view>

        <!-- 所有选择的药品列表 -->
        <view class="medicines-section" v-if="allCartItems.length > 0">
          <view class="medicines-header">
            <text class="medicines-title">已选择的药品 ({{ allCartItems.length }}种)</text>
          </view>
          <view class="medicines-list">
            <view 
              class="medicine-item"
              v-for="(item, index) in allCartItems" 
              :key="item.id"
            >
              <view class="medicine-left">
                <image class="medicine-thumb" :src="item.image" mode="aspectFill" />
                <view class="medicine-qty" v-if="item.quantity">×{{ item.quantity }}</view>
              </view>
              <view class="medicine-right">
                <view class="medicine-name">{{ item.name }}</view>
                <view class="medicine-price">¥{{ ((item.price || 0) * (item.quantity || 1)).toFixed(2) }}</view>
              </view>
            </view>
          </view>
        </view>

        <!-- 底部按钮 -->
        <view class="btn-row">
          <button class="primary-btn" @tap="handleView">点击查看</button>
        </view>
      </view>
    </view>
  </template>
  
  <script>
  import { loadCartItems } from '@/utils/cart.js'
  
  export default {
    name: 'OrderDetail',
    data() {
      return {
        order: {
          amount: '31.61',
          statusText: '待下单',
          time: '11-16 16:13',
          prescriptionNo: '17675708',
          diagnosis: '虚劳类病',
          doctor: '徐俐颖 便捷配药门诊',
          hospital: '浙江省中医院（湖滨院区）'
        },
        allCartItems: [] // 所有购物车商品
      }
    },
    onLoad(options) {
      // 从路由参数中获取订单数据
      if (options.order) {
        try {
          const orderData = JSON.parse(decodeURIComponent(options.order))
          this.order = {
            ...this.order,
            ...orderData
          }
          // 格式化时间
          if (this.order.time) {
            this.order.time = this.formatDateTime(this.order.time)
          }
        } catch (e) {
          console.error('解析订单数据失败:', e)
        }
      }
      
      // 加载购物车中的所有商品
      this.loadCartItems()
    },
    computed: {
      infoList() {
        return [
          { label: '处方单号', labelKey: 'prescriptionNo', value: this.order.prescriptionNo },
          { label: '临床诊断', labelKey: 'diagnosis', value: this.order.diagnosis },
          { label: '开方医生', labelKey: 'doctor', value: this.order.doctor },
          { label: '开方医院', labelKey: 'hospital', value: this.order.hospital }
        ]
      },
      // 计算购物车中所有药品的总金额
      totalAmount() {
        return this.allCartItems.reduce((total, item) => {
          const price = item.price || 0
          const quantity = item.quantity || 1
          return total + (price * quantity)
        }, 0)
      }
    },
    methods: {
      // 格式化日期时间为 YYYY-MM-DD HH:mm:ss
      formatDateTime(dateTimeStr) {
        if (!dateTimeStr) {
          return ''
        }
        
        try {
          // 如果已经是 YYYY-MM-DD HH:mm:ss 格式，直接返回
          if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(dateTimeStr)) {
            return dateTimeStr
          }
          
          let date
          
          // 如果是时间戳（数字）
          if (typeof dateTimeStr === 'number') {
            date = new Date(dateTimeStr)
          }
          // 如果是字符串
          else if (typeof dateTimeStr === 'string') {
            // 尝试解析为日期对象
            date = new Date(dateTimeStr)
          } else {
            return dateTimeStr
          }
          
          // 验证日期是否有效
          if (isNaN(date.getTime())) {
            return dateTimeStr
          }
          
          // 格式化为 YYYY-MM-DD HH:mm:ss
          const year = date.getFullYear()
          const month = String(date.getMonth() + 1).padStart(2, '0')
          const day = String(date.getDate()).padStart(2, '0')
          const hours = String(date.getHours()).padStart(2, '0')
          const minutes = String(date.getMinutes()).padStart(2, '0')
          const seconds = String(date.getSeconds()).padStart(2, '0')
          
          return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
        } catch (e) {
          console.error('格式化日期时间失败:', e)
          return dateTimeStr
        }
      },
      
      handleView() {
        // 跳转到处方详情页
        uni.navigateTo({
          url: `/pages/prescription/detail?prescriptionNo=${this.order.prescriptionNo}`
        })
      },
      
      // 加载产品数据
      loadProducts() {
        return new Promise((resolve) => {
          uni.request({
            url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
            method: 'GET',
            success: (res) => {
              if (res.data && res.data.categories) {
                resolve(res.data.categories)
              } else {
                resolve([])
              }
            },
            fail: () => {
              // 使用本地备用数据
              resolve([
                {
                  id: 'zhou',
                  name: '养生粥',
                  products: [
                    { id: 'zhou1', name: '养生粥系列一', price: 28.00, image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png' },
                    { id: 'zhou2', name: '养生粥系列二', price: 32.00, image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png' },
                    { id: 'zhou3', name: '养生粥系列三', price: 30.00, image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png' }
                  ]
                },
                {
                  id: 'gaoyao',
                  name: '辽派滋膏',
                  products: [
                    { id: 'gaoyao1', name: '辽派滋膏系列一', price: 88.00, image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png' },
                    { id: 'gaoyao2', name: '辽派滋膏系列二', price: 95.00, image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png' }
                  ]
                }
              ])
            }
          })
        })
      },
      
      // 加载购物车数据
      loadCartItems() {
        this.loadProducts().then(categories => {
          this.allCartItems = loadCartItems(categories)
          console.log('加载的购物车商品:', this.allCartItems)
        })
      }
    }
  }
  </script>
  
  <style scoped lang="scss">
  .page {
    min-height: 100vh;
    background-color: #f5f5f5;
    padding: 24rpx 24rpx 40rpx;
    box-sizing: border-box;
  }
  
  /* 白色订单卡片 */
  .order-card {
    background-color: #ffffff;
    border-radius: 16rpx;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.04);
    overflow: hidden;
  }
  
  /* 顶部区域 */
  .order-header {
    padding: 32rpx 32rpx 24rpx;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }
  
  .order-header-left {
    display: flex;
    flex-direction: column;
  }
  
  .title-row {
    display: flex;
    align-items: center;
  }
  
  .icon-circle {
    line-height: 1;
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    background-color: #eef3ff;
    justify-content: center;
    align-items: center;
    display: flex;
    margin-right: 12rpx;
  }
  
  .icon-plus {
    margin: 0;
    font-size: 32rpx;
    color: #2f7cf6;
  }
  
  .title-text {
    font-size: 30rpx;
    color: #333333;
  }
  
  .amount-text {
    margin-top: 28rpx;
    font-size: 52rpx;
    font-weight: 600;
    color: #111111;
  }
  
  /* 右侧状态区域 */
  .order-header-right {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }
  
  .status-text {
    font-size: 28rpx;
    color: #2f7cf6;
    margin-bottom: 12rpx;
  }
  
  .time-text {
    font-size: 24rpx;
    color: #999999;
  }
  
  /* 分割线 */
  .divider {
    height: 1px;
    background-color: #f1f1f1;
    margin: 0 32rpx;
  }
  
  /* 信息行 */
  .info-row {
    padding: 22rpx 32rpx;
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  
  .info-label {
    font-size: 26rpx;
    color: #999999;
    width: 160rpx;
  }
  
  .info-value {
    font-size: 28rpx;
    color: #333333;
    flex: 1;
  }
  
  /* 按钮区域 */
  .btn-row {
    padding: 32rpx 32rpx 40rpx;
    display: flex;
    justify-content: flex-end;
  }
  
  .primary-btn {
    width: 420rpx;
    height: 88rpx;
    line-height: 88rpx;
    background-color: #2f7cf6;
    color: #ffffff;
    font-size: 30rpx;
    border-radius: 999rpx;
    text-align: center;
    padding: 0;
    border: none;
  }
  
  /* 去掉默认边框/背景（小程序端） */
  .primary-btn::after {
    border: none;
  }
  
  /* 药品列表区域 */
  .medicines-section {
    margin: 0 32rpx;
    padding: 24rpx 0;
    border-top: 1px solid #f1f1f1;
  }
  
  .medicines-header {
    margin-bottom: 20rpx;
    padding-bottom: 16rpx;
    border-bottom: 1rpx solid #f0f0f0;
  }
  
  .medicines-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333333;
  }
  
  .medicines-list {
    display: flex;
    flex-direction: column;
    gap: 20rpx;
  }
  
  .medicine-item {
    display: flex;
    align-items: center;
    position: relative;
    padding: 16rpx;
    background: #f9f9f9;
    border-radius: 8rpx;
  }
  
  .medicine-left {
    position: relative;
    width: 120rpx;
    height: 120rpx;
    margin-right: 20rpx;
    flex-shrink: 0;
  }
  
  .medicine-thumb {
    width: 100%;
    height: 100%;
    border-radius: 8rpx;
    background: #eee;
  }
  
  .medicine-qty {
    position: absolute;
    right: -8rpx;
    top: -8rpx;
    background: #fff;
    color: #333;
    padding: 4rpx 10rpx;
    border-radius: 12rpx;
    font-size: 22rpx;
    border: 1rpx solid #ddd;
    font-weight: 600;
  }
  
  .medicine-right {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 8rpx;
  }
  
  .medicine-name {
    font-size: 28rpx;
    font-weight: 500;
    color: #333333;
  }
  
  .medicine-price {
    color: #e64340;
    font-size: 26rpx;
    font-weight: 600;
  }
  </style>
  