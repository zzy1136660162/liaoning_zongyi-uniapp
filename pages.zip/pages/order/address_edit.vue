<template>
  <view class="page">
    <view style="padding: 20rpx;">

    
    <!-- 表单内容 -->
    <scroll-view class="form-content" scroll-y>
      <view class="form-section">
        <view class="form-item">
          <text class="label"><text class="required">*</text> 收货人</text>
          <input 
            class="input" 
            v-model="formData.name" 
            placeholder="请输入收货人姓名"
            maxlength="20"
          />
        </view>
        
        <view class="form-item">
          <text class="label"><text class="required">*</text> 手机号</text>
          <input 
            class="input" 
            v-model="formData.phone" 
            placeholder="请输入手机号"
            type="number"
            maxlength="11"
          />
        </view>
        
        <view class="form-item">
          <text class="label"><text class="required">*</text> 省市区</text>
          <input 
            class="input" 
            v-model="formData.region" 
            placeholder="请输入省市区"
            maxlength="50"
          />
        </view>
        
        <view class="form-item">
          <text class="label"><text class="required">*</text> 街道</text>
          <input 
            class="input" 
            v-model="formData.street" 
            placeholder="请输入街道"
            maxlength="50"
          />
        </view>
        
        <view class="form-item">
          <text class="label"><text class="required">*</text> 详细地址</text>
          <textarea 
            class="textarea" 
            v-model="formData.detail" 
            placeholder="请输入详细地址，如门牌号、楼层等"
            maxlength="100"
            :auto-height="true"
          />
        </view>
        
        <view class="form-item checkbox-item" @click="toggleDefault">
          <text class="label">设为默认地址</text>
          <view 
            class="checkbox" 
            :class="{ checked: formData.isDefault }"
          ></view>
        </view>
      </view>
    </scroll-view>
  </view>
    <!-- 底部保存按钮 -->
    <view class="footer">
      <button class="save-btn" @click="saveAddress">保存</button>
    </view>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { 
  STORAGE_KEY_SHIPPING_ADDRESSES,
  STORAGE_KEY_DEFAULT_ADDRESS_ID
} from '@/utils/storage.js'

const isEdit = ref(false)
const addressId = ref(null)

const formData = reactive({
  name: '',
  phone: '',
  region: '',
  province: '',
  city: '',
  district: '',
  street: '',
  detail: '',
  isDefault: false
})

onMounted(() => {
  // 检查是否是编辑模式
  const pages = getCurrentPages()
  const currentPage = pages[pages.length - 1]
  if (currentPage && currentPage.options && currentPage.options.id) {
    isEdit.value = true
    addressId.value = currentPage.options.id
    loadAddress()
    // 设置导航栏标题
    uni.setNavigationBarTitle({
      title: '编辑地址'
    })
  } else {
    // 设置导航栏标题
    uni.setNavigationBarTitle({
      title: '新增地址'
    })
  }
})

const loadAddress = () => {
  try {
    const addresses = uni.getStorageSync(STORAGE_KEY_SHIPPING_ADDRESSES) || []
    const address = addresses.find(a => a.id === addressId.value)
    if (address) {
      formData.name = address.name || ''
      formData.phone = address.phone || ''
      // 如果有region字段，直接使用；否则合并province、city、district
      formData.region = address.region || ((address.province || '') + (address.city || '') + (address.district || ''))
      formData.province = address.province || ''
      formData.city = address.city || ''
      formData.district = address.district || ''
      formData.street = address.street || ''
      formData.detail = address.detail || ''
      formData.isDefault = address.isDefault || false
    }
  } catch (e) {
    console.error('加载地址失败:', e)
  }
}


const toggleDefault = () => {
  formData.isDefault = !formData.isDefault
}

const validateForm = () => {
  if (!formData.name || formData.name.trim() === '') {
    uni.showToast({ title: '请输入收货人姓名', icon: 'none' })
    return false
  }
  
  if (!formData.phone || formData.phone.trim() === '') {
    uni.showToast({ title: '请输入手机号', icon: 'none' })
    return false
  }
  
  const phoneReg = /^1[3-9]\d{9}$/
  if (!phoneReg.test(formData.phone)) {
    uni.showToast({ title: '请输入正确的手机号', icon: 'none' })
    return false
  }
  
  if (!formData.region || formData.region.trim() === '') {
    uni.showToast({ title: '请输入省市区', icon: 'none' })
    return false
  }
  
  if (!formData.street || formData.street.trim() === '') {
    uni.showToast({ title: '请输入街道', icon: 'none' })
    return false
  }
  
  if (!formData.detail || formData.detail.trim() === '') {
    uni.showToast({ title: '请输入详细地址', icon: 'none' })
    return false
  }
  
  return true
}

const saveAddress = () => {
  if (!validateForm()) {
    return
  }
  
  try {
    let addresses = uni.getStorageSync(STORAGE_KEY_SHIPPING_ADDRESSES) || []
    
    if (isEdit.value) {
      // 编辑模式：更新地址
      const index = addresses.findIndex(a => a.id === addressId.value)
      if (index > -1) {
        addresses[index] = {
          ...addresses[index],
          ...formData,
          id: addressId.value
        }
      }
    } else {
      // 新增模式：添加新地址
      const newAddress = {
        id: Date.now().toString(),
        ...formData,
        createdAt: new Date().toISOString()
      }
      addresses.push(newAddress)
    }
    
    // 如果设置为默认地址，清除其他默认地址
    if (formData.isDefault) {
      addresses.forEach(addr => {
        if (addr.id !== (isEdit.value ? addressId.value : null)) {
          addr.isDefault = false
        }
      })
      const targetId = isEdit.value ? addressId.value : addresses[addresses.length - 1].id
      uni.setStorageSync(STORAGE_KEY_DEFAULT_ADDRESS_ID, targetId)
    } else if (isEdit.value) {
      // 如果取消默认地址，清除默认地址ID
      const defaultId = uni.getStorageSync(STORAGE_KEY_DEFAULT_ADDRESS_ID)
      if (defaultId === addressId.value) {
        uni.removeStorageSync(STORAGE_KEY_DEFAULT_ADDRESS_ID)
      }
    }
    
    uni.setStorageSync(STORAGE_KEY_SHIPPING_ADDRESSES, addresses)
    
    uni.showToast({ 
      title: isEdit.value ? '保存成功' : '添加成功', 
      icon: 'success',
      success: () => {
        setTimeout(() => {
          uni.navigateBack()
        }, 1500)
      }
    })
  } catch (e) {
    console.error('保存地址失败:', e)
    uni.showToast({ title: '保存失败', icon: 'none' })
  }
}

</script>

<style scoped>
.page {
  background: #f6f7fb;
  min-height: 100vh;
  padding-bottom: calc(120rpx + env(safe-area-inset-bottom));
}

.form-content {
  flex: 1;
}

.form-section {
  background: #fff;
  border-radius: 8rpx;
  padding: 20rpx;
}

.form-item {
  display: flex;
  align-items: center;
  padding: 24rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}

.form-item:last-child {
  border-bottom: none;
}

.label {
  width: 200rpx;
  font-size: 28rpx;
  color: #333;
  flex-shrink: 0;
}

.required {
  color: #ff4d4f;
  margin-right: 4rpx;
}

.input {
  flex: 1;
  font-size: 28rpx;
  color: #333;
}

.textarea {
  flex: 1;
  font-size: 28rpx;
  color: #333;
  min-height: 120rpx;
  line-height: 1.6;
}

.region-value {
  flex: 1;
  font-size: 28rpx;
  color: #333;
}

.placeholder {
  color: #999;
}

.arrow {
  color: #999;
  font-size: 28rpx;
  margin-left: 12rpx;
}

.checkbox-item {
  justify-content: space-between;
  cursor: pointer;
}

.checkbox-item:active {
  opacity: 0.7;
}

.checkbox {
  width: 36rpx;
  height: 36rpx;
  border: 2rpx solid #ddd;
  border-radius: 50%;
  position: relative;
  flex-shrink: 0;
}

.checkbox.checked {
  background: #2a82e4;
  border-color: #2a82e4;
}

.checkbox.checked::after {
  content: '✓';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #fff;
  font-size: 24rpx;
}

.footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  padding: 20rpx;
  padding-bottom: calc(20rpx + env(safe-area-inset-bottom));
  box-shadow: 0 -4rpx 12rpx rgba(0,0,0,0.1);
  z-index: 100;
}

.save-btn {
  width: 100%;
  background: #2a82e4;
  color: #fff;
  font-size: 30rpx;
  padding: 16rpx 0;
  border-radius: 8rpx;
  border: none;
}
</style>

