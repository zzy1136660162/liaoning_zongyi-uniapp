<template>
    <view class="page">
      <!-- 医院和用户信息 -->
      <view class="header-info">
        <view class="hospital">{{ hospitalName }}</view>
        <view class="user-info" @click="onSelectUser">
          {{ currentUserName }}
        </view>
      </view>
      
      <!-- 日期选择 -->
      <view class="date-section">
        <view class="date-label">日期选择</view>
        <view class="date-range" @click="onSelectDate">
          {{ dateRange.start }} - {{ dateRange.end }}
        </view>
      </view>
      
      <!-- 筛选标签 -->
      <view class="filter-tabs">
        <view 
          v-for="tab in tabs" 
          :key="tab.key"
          class="tab-item"
          :class="{ active: activeTab === tab.key }"
          @click="switchTab(tab.key)"
        >
          {{ tab.label }}
          <view v-if="tab.count > 0" class="tab-badge">{{ tab.count }}</view>
        </view>
      </view>
      <view style="padding: 20rpx;">
      <!-- 处方列表 -->
      <scroll-view class="prescription-list" scroll-y>
        <!-- 全选控制 -->
        <view class="select-all-bar">
          <view class="select-all" @click="toggleSelectAll">
            <view class="checkbox" :class="{ checked: isAllSelected }"></view>
            <text>全选</text>
          </view>
          <view class="consultation-time">就诊时间: {{ latestConsultationTime }}</view>
        </view>
        
        <!-- 处方项 -->
        <template v-for="(prescription,index) in filteredPrescriptions" :key="prescription.id">
          <view 
            v-if="index==0"
            class="prescription-item"
          >
            <view class="prescription-checkbox" @click="toggleSelect(prescription.id)">
              <view class="checkbox" :class="{ checked: selectedIds.includes(prescription.id) }"></view>
            </view>
            
            <view class="prescription-content" @click="onPrescriptionClick(prescription)">
              <view class="prescription-header">
                <text class="doctor-name">{{ prescription.doctorName }} {{ prescription.department }}</text>
              </view>
              
              <view class="prescription-tags">
                <view 
                  v-for="tag in prescription.tags" 
                  :key="tag"
                  class="tag"
                  :class="{ 'tag-secret': tag === '密' }"
                >
                  {{ tag }}
                </view>
              </view>
              
              <view class="prescription-info">
                <text class="info-label">诊断:</text>
                <text class="info-value">{{ prescription.diagnosis }}</text>
              </view>
              
              <view 
                class="prescription-info prescription-info-inline"
                v-for="(cartItem, cartIndex) in cartItemsList"
                :key="cartIndex"
              >
                <text class="info-label">数量:</text>
                <text class="info-value">{{ cartItem.quantity }}</text>
                <text class="info-label info-label-spaced">明细:</text>
                <text class="info-value">{{ cartItem.name }}</text>
              </view>
              
              <view class="prescription-footer">
                <view class="prescription-status">
                  <text class="status-text">待下单</text>
                  <text class="status-time">{{ prescription.timeLimit }}</text>
                </view>
                <button class="feedback-btn" @click.stop="onFeedback(prescription.id)">意见反馈</button>
              </view>
            </view>
          </view>
        </template>
      </scroll-view>
    </view>
      <!-- 药品明细卡片 -->
      <!-- <view class="medicine-detail-card" v-if="selectedCount > 0 && cartItemsList.length > 0">
        <view class="detail-title">药品明细</view>
        <view 
          v-for="item in cartItemsList" 
          :key="item.id"
          class="medicine-item"
        >
          <view class="medicine-name">{{ item.name }}</view>
          <view class="medicine-info">
            <text class="medicine-quantity">×{{ item.quantity }}</text>
            <text class="medicine-price">¥{{ (item.price * item.quantity).toFixed(2) }}</text>
          </view>
        </view>
      </view> -->
      <!-- 底部操作栏 -->
      <view class="footer" v-if="selectedCount > 0">
        <view class="footer-left">
          <view>已选择 <text class="selected-count">{{ selectedCount }}</text> 张处方单</view>
          <view class="total-amount">合计: ¥<text class="amount-value">{{ totalAmount.toFixed(2) }}</text></view>
        </view>
        <button class="order-btn" @click="goToOrder">去下单</button>
      </view>
    </view>
  </template>
  
  <script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import { 
  STORAGE_KEY_PRESCRIPTION_ORDERS, 
  STORAGE_KEY_SELECTED_PRESCRIPTIONS,
  STORAGE_KEY_USER_REGISTER,
  STORAGE_KEY_CURRENT_ORDER,
  STORAGE_KEY_VERIFIED_PRODUCTS,
  STORAGE_KEY_PRODUCT_QUANTITIES
} from '@/utils/storage.js'
import { loadCartItems, buildOrderInfo, calculateTotalPrice } from '@/utils/cart.js'
  
  const hospitalName = ref('辽宁中医药大学附属医院')
  const currentUserName = ref('')
  const activeTab = ref('pending_payment')
  const selectedIds = ref([])
  const dateRange = ref({
    start: '2025-08-15',
    end: '2025-11-15'
  })
  
  const tabs = ref([
    { key: 'all', label: '全部', count: 0 },
    { key: 'pending_review', label: '待审方', count: 0 },
    { key: 'pending_payment', label: '待缴费', count: 0 },
    { key: 'collecting', label: '收取中', count: 0 },
    { key: 'finished', label: '已结束', count: 0 }
  ])
  
  const prescriptions = ref([])
  const categories = ref([])
  
  // 加载数据
  onMounted(() => {
    loadProducts()
    loadUserInfo()
  })
  
  const loadUserInfo = () => {
    try {
      const userInfo = uni.getStorageSync(STORAGE_KEY_USER_REGISTER)
      if (userInfo && userInfo.realName) {
        currentUserName.value = userInfo.realName
      }
    } catch (e) {
      console.error('加载用户信息失败:', e)
    }
  }
  
  // 加载产品数据
  const loadProducts = () => {
    uni.request({
      url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
      method: 'GET',
      success: (res) => {
        if (res.data && res.data.categories) {
          categories.value = res.data.categories
          loadPrescriptions()
        }
      },
      fail: (err) => {
        console.error('加载产品数据失败:', err)
        loadLocalData()
        loadPrescriptions()
      }
    })
  }
  
  // 加载本地产品数据（备用）
  const loadLocalData = () => {
    const noticeText = '开方前需要先了解该药物是否适合您，请如实填写，以便判断该药物是否适合您\n\n【适应人群】皮肤干燥、口干咽干、容易口渴大便不稀薄的人群\n\n【注意事项】:糖尿病患者及有高血压、心脏病、肝病、肾病等慢性病严重者应在医师指导下用药。'
    
    categories.value = [
      {
        id: 'zhou',
        name: '养生粥',
        products: [
          {
            id: 'zhou1',
            name: '养生粥系列一',
            description: '精选优质食材，营养丰富，适合日常养生',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png',
            unit: '1',
            price: 28.00,
            notice: noticeText
          },
          {
            id: 'zhou2',
            name: '养生粥系列二',
            description: '温补养胃，适合脾胃虚弱者',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png',
            unit: '1',
            price: 32.00,
            notice: noticeText
          },
          {
            id: 'zhou3',
            name: '养生粥系列三',
            description: '滋阴润燥，适合秋冬季节',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png',
            unit: '1',
            price: 30.00,
            notice: noticeText
          }
        ]
      },
      {
        id: 'gaoyao',
        name: '辽派滋膏',
        products: [
          {
            id: 'gaoyao1',
            name: '辽派滋膏系列一',
            description: '传统工艺，滋补养生，适合体虚者',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png',
            unit: '1',
            price: 88.00,
            notice: noticeText
          },
          {
            id: 'gaoyao2',
            name: '辽派滋膏系列二',
            description: '精选药材，补气养血，增强体质',
            image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png',
            unit: '1',
            price: 95.00,
            notice: noticeText
          }
        ]
      }
    ]
  }
  
  const loadPrescriptions = () => {
    try {
      // 优先从 STORAGE_KEY_PRESCRIPTION_ORDERS 读取处方列表（与订单一致）
      let prescriptionOrders = uni.getStorageSync(STORAGE_KEY_PRESCRIPTION_ORDERS) || []
      
      // 如果 storage 中没有处方订单，则从已验证的产品生成处方列表
      if (prescriptionOrders.length === 0) {
        // 使用统一的工具函数加载购物车数据
        const cartItems = loadCartItems(categories.value)
        
        const now = new Date()
        const consultationTime = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
        
        let prescriptionIndex = 1
        // 为每个购物车商品生成一个处方
        for (let item of cartItems) {
          prescriptionOrders.push({
            id: String(prescriptionIndex),
            visitNo: String(prescriptionIndex), // 添加 visitNo 字段
            doctorName: '线上名医',
            department: '便捷配药门诊',
            consultationTime: consultationTime,
            diagnosis: '虚劳类病',
            doses: item.quantity || 1,
            details: item.name,
            status: 'pending_payment',
            tags: ['在线复诊', '中药方', '密', '便捷配药'],
            timeLimit: '1分钟内',
            hospital: hospitalName.value,
            createdAt: new Date().toISOString(),
            productId: item.id,
            productPrice: item.price,
            quantity: item.quantity || 1
          })
          prescriptionIndex++
        }
        
        // 将生成的处方列表保存到 storage
        if (prescriptionOrders.length > 0) {
          uni.setStorageSync(STORAGE_KEY_PRESCRIPTION_ORDERS, prescriptionOrders)
        }
      }
      
      // 设置处方列表
      prescriptions.value = prescriptionOrders
      
      // 更新标签计数
      updateTabCounts()
      
      // 加载已选中的处方
      const savedSelected = uni.getStorageSync(STORAGE_KEY_SELECTED_PRESCRIPTIONS) || []
      selectedIds.value = savedSelected
      
      // 如果没有已保存的选择，默认选中第一项
      nextTick(() => {
        if (selectedIds.value.length === 0 && filteredPrescriptions.value.length > 0) {
          const firstPrescription = filteredPrescriptions.value[0]
          if (firstPrescription) {
            selectedIds.value = [firstPrescription.id]
            saveSelectedPrescriptions()
          }
        }
      })
      
      // 如果没有处方，提示用户
      if (prescriptions.value.length === 0) {
        uni.showToast({
          title: '暂无处方',
          icon: 'none'
        })
      }
    } catch (e) {
      console.error('加载处方列表失败:', e)
    }
  }
  
  const updateTabCounts = () => {
    // 因为只显示第一项处方，所以标签计数最多为1
    const firstPrescription = prescriptions.value.length > 0 ? prescriptions.value[0] : null
    
    tabs.value.forEach(tab => {
      if (tab.key === 'all') {
        // 全部标签：如果有第一项就显示1，否则显示0
        tab.count = firstPrescription ? 1 : 0
      } else {
        // 其他标签：如果第一项的状态匹配该标签，则显示1，否则显示0
        tab.count = (firstPrescription && firstPrescription.status === tab.key) ? 1 : 0
      }
    })
  }
  
  const filteredPrescriptions = computed(() => {
    if (activeTab.value === 'all') {
      return prescriptions.value
    }
    return prescriptions.value.filter(p => p.status === activeTab.value)
  })
  
  const latestConsultationTime = computed(() => {
    if (filteredPrescriptions.value.length === 0) return ''
    return filteredPrescriptions.value[0].consultationTime
  })
  
  const selectedCount = computed(() => {
    // 因为只显示第一项处方，所以最多只能选中1个
    return Math.min(selectedIds.value.length, 1)
  })
  
  const isAllSelected = computed(() => {
    // 只检查第一项是否被选中（因为只显示第一项）
    if (filteredPrescriptions.value.length === 0) return false
    const firstPrescription = filteredPrescriptions.value[0]
    return firstPrescription ? selectedIds.value.includes(firstPrescription.id) : false
  })
  
  // 获取处方对应的购物车商品（与下方明细保持一致）
  const getPrescriptionCartItems = (prescription) => {
    if (!prescription || !prescription.productId) {
      return []
    }
    
    // 从购物车中找到对应的商品
    const cartItem = cartItemsList.value.find(item => item.id === prescription.productId)
    
    if (cartItem) {
      // 返回与下方明细格式一致的数据
      return [{
        id: cartItem.id,
        name: cartItem.name,
        quantity: cartItem.quantity,
        price: cartItem.price
      }]
    }
    
    return []
  }
  
  // 获取购物车内所有药品列表
  const cartItemsList = computed(() => {
    if (categories.value.length === 0) {
      return []
    }
    
    // 加载购物车数据
    return loadCartItems(categories.value)
  })
  
  // 计算购物车内所有药品的总金额（价格 × 数量）
  const totalAmount = computed(() => {
    if (cartItemsList.value.length === 0) {
      return 0
    }
    
    // 计算购物车内所有商品的总金额（价格 × 数量）
    return calculateTotalPrice(cartItemsList.value)
  })
  
  const switchTab = (key) => {
    activeTab.value = key
    // 切换标签时清空选择，然后默认选中第一项
    selectedIds.value = []
    
    // 使用 nextTick 确保 filteredPrescriptions 已更新
    nextTick(() => {
      if (filteredPrescriptions.value.length > 0) {
        const firstPrescription = filteredPrescriptions.value[0]
        if (firstPrescription) {
          selectedIds.value = [firstPrescription.id]
        }
      }
      saveSelectedPrescriptions()
    })
  }
  
  const toggleSelect = (id) => {
    // 因为只显示第一项，所以只能操作第一项
    const firstPrescription = filteredPrescriptions.value.length > 0 ? filteredPrescriptions.value[0] : null
    if (!firstPrescription || firstPrescription.id !== id) {
      // 如果尝试操作的不是第一项，直接返回
      return
    }
    
    const index = selectedIds.value.indexOf(id)
    if (index > -1) {
      selectedIds.value.splice(index, 1)
    } else {
      // 选中时，先清空其他选择，只保留当前项
      selectedIds.value = [id]
    }
    saveSelectedPrescriptions()
  }
  
  const toggleSelectAll = () => {
    // 只对第一项进行全选/取消全选（因为只显示第一项）
    if (filteredPrescriptions.value.length === 0) return
    
    const firstPrescription = filteredPrescriptions.value[0]
    if (!firstPrescription) return
    
    if (isAllSelected.value) {
      // 取消全选（取消第一项）
      const index = selectedIds.value.indexOf(firstPrescription.id)
      if (index > -1) {
        selectedIds.value.splice(index, 1)
      }
    } else {
      // 全选（选中第一项）
      if (!selectedIds.value.includes(firstPrescription.id)) {
        selectedIds.value.push(firstPrescription.id)
      }
    }
    saveSelectedPrescriptions()
  }
  
  const saveSelectedPrescriptions = () => {
    uni.setStorageSync(STORAGE_KEY_SELECTED_PRESCRIPTIONS, selectedIds.value)
  }
  
  const onSelectUser = () => {
    // 选择用户（示例）
    uni.showToast({ title: '选择用户', icon: 'none' })
  }
  
  const onSelectDate = () => {
    // 选择日期（示例）
    uni.showToast({ title: '选择日期', icon: 'none' })
  }
  
  const onFeedback = (id) => {
    uni.showToast({ title: '意见反馈', icon: 'none' })
  }
  
  const onPrescriptionClick = (prescription) => {
    // 确保传递完整的处方数据
    console.log('点击的处方数据:', prescription)
    
    // 构建完整的处方数据对象
    const prescriptionData = {
      id: prescription.id,
      doctorName: prescription.doctorName,
      department: prescription.department,
      consultationTime: prescription.consultationTime,
      diagnosis: prescription.diagnosis,
      doses: prescription.doses,
      details: prescription.details,
      status: prescription.status,
      tags: prescription.tags,
      timeLimit: prescription.timeLimit,
      hospital: prescription.hospital,
      productId: prescription.productId,
      productPrice: prescription.productPrice,
      quantity: prescription.quantity
    }
    
    // 跳转到处方详情页
    const encodedData = encodeURIComponent(JSON.stringify(prescriptionData))
    uni.navigateTo({
      url: `/pages/order/prescription_detail?prescription=${encodedData}`,
      success: () => {
        console.log('跳转到详情页成功')
      },
      fail: (err) => {
        console.error('跳转失败:', err)
        uni.showToast({
          title: '跳转失败，请重试',
          icon: 'none'
        })
      }
    })
  }
  
  const goToOrder = () => {
    if (selectedIds.value.length === 0) {
      uni.showToast({ title: '请选择处方', icon: 'none' })
      return
    }
    
    try {
      // 使用统一的工具函数加载购物车数据
      const cartItems = loadCartItems(categories.value)
      
      // 获取选中的处方对应的产品ID
      const selectedPrescriptions = prescriptions.value.filter(p => selectedIds.value.includes(p.id))
      const selectedProductIds = selectedPrescriptions.map(p => p.productId || p.id)
      
      // 使用统一的工具函数构建订单信息
      const orderInfo = buildOrderInfo(cartItems, selectedProductIds, hospitalName.value)
      
      // 保存订单信息
      uni.setStorageSync(STORAGE_KEY_CURRENT_ORDER, orderInfo)
      
      // 跳转到订单确认页面
      uni.navigateTo({
        url: '/pages/order/confirm'
      })
    } catch (e) {
      console.error('构建订单信息失败:', e)
      uni.showToast({
        title: '构建订单失败，请重试',
        icon: 'none'
      })
    }
  }
  </script>
  
  <style scoped>
  .page {
    background: #f6f7fb;
    min-height: 100vh;
    padding-bottom: 200rpx;
  }
  
  .header-info {
    background: #fff;
    padding: 20rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1rpx solid #eee;
  }
  
  .hospital {
    font-size: 28rpx;
    color: #333;
  }
  
  .user-info {
    font-size: 28rpx;
    color: #333;
  }
  
  .date-section {
    background: #fff;
    padding: 20rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1rpx solid #eee;
  }
  
  .date-label {
    font-size: 28rpx;
    color: #333;
  }
  
  .date-range {
    font-size: 28rpx;
    color: #666;
  }
  
  .filter-tabs {
    background: #fff;
    display: flex;
    padding: 20rpx 0;
    border-bottom: 1rpx solid #eee;
  }
  
  .tab-item {
    flex: 1;
    text-align: center;
    font-size: 28rpx;
    color: #666;
    position: relative;
    padding: 10rpx 0;
  }
  
  .tab-item.active {
    color: #2a82e4;
    font-weight: 600;
  }
  
  .tab-badge {
    position: absolute;
    top: -20rpx;
    right: 20rpx;
    background: #ff4d4f;
    color: #fff;
    font-size: 20rpx;
    padding: 2rpx 8rpx;
    border-radius: 20rpx;
    min-width: 32rpx;
    text-align: center;
  }
  
  .prescription-list {
    flex: 1;
  }
  
  .select-all-bar {
    background: #fff;
    padding: 20rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20rpx;
    border-radius: 8rpx;
  }
  
  .select-all {
    display: flex;
    align-items: center;
    gap: 12rpx;
    font-size: 28rpx;
    color: #333;
  }
  
  .checkbox {
    width: 36rpx;
    height: 36rpx;
    border: 2rpx solid #ddd;
    border-radius: 50%;
    position: relative;
  }
  
  .checkbox.checked {
    background: #2a82e4;
    border-color: #2a82e4;
  }
  
  .checkbox.checked::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
    font-size: 24rpx;
  }
  
  .consultation-time {
    font-size: 24rpx;
    color: #999;
  }
  .selected-count{
    color: #ff4d4f;
    font-size: 36rpx;
    font-weight:bold;
  }
  .prescription-item {
    background: #fff;
    border-radius: 8rpx;
    padding: 20rpx;
    margin-bottom: 20rpx;
    display: flex;
    gap: 20rpx;
  }
  
  .prescription-checkbox {
    display: flex;
    align-items: flex-start;
    padding-top: 4rpx;
  }
  
  .prescription-content {
    flex: 1;
    cursor: pointer;
  }
  
  .prescription-header {
    margin-bottom: 12rpx;
  }
  
  .doctor-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
  }
  
  .prescription-tags {
    display: flex;
    gap: 12rpx;
    margin-bottom: 16rpx;
    flex-wrap: wrap;
  }
  
  .tag {
    padding: 4rpx 12rpx;
    background: #f0f6ff;
    color: #2a82e4;
    font-size: 22rpx;
    border-radius: 4rpx;
  }
  
  .tag-secret {
    background: #fff7e6;
    color: #faad14;
  }
  
  .prescription-info {
    margin-bottom: 8rpx;
    font-size: 26rpx;
  }
  
  .prescription-info-inline {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }
  
  .info-label {
    color: #666;
    margin-right: 8rpx;
  }
  
  .info-label-spaced {
    margin-left: 20rpx;
  }
  
  .info-value {
    color: #333;
  }
  
  .prescription-footer {
    padding-right: 30rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 16rpx;
    padding-top: 16rpx;
    border-top: 1rpx solid #eee;
  }
  
  .prescription-status {
    display: flex;
    flex-direction: column;
    gap: 4rpx;
  }
  
  .status-text {
    font-size: 28rpx;
    color: #333;
  }
  
  .status-time {
    font-size: 24rpx;
    color: #999;
  }
  
  .feedback-btn {
    margin: 0;
    background: #f5f5f5;
    color: #666;
    font-size: 24rpx;
    padding: 8rpx 20rpx;
    border-radius: 4rpx;
    border: none;
  }
  
  .medicine-detail-card {
    position: fixed;
    left: 20rpx;
    right: 20rpx;
    bottom: 160rpx;
    background: #fff;
    border-radius: 8rpx;
    padding: 20rpx;
    box-shadow: 0 -4rpx 12rpx rgba(0,0,0,0.1);
    z-index: 99;
    max-height: 400rpx;
    overflow-y: auto;
  }
  
  .detail-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    margin-bottom: 16rpx;
    padding-bottom: 12rpx;
    border-bottom: 1rpx solid #eee;
  }
  
  .medicine-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12rpx 0;
    border-bottom: 1rpx solid #f0f0f0;
  }
  
  .medicine-item:last-child {
    border-bottom: none;
  }
  
  .medicine-name {
    flex: 1;
    font-size: 28rpx;
    color: #333;
  }
  
  .medicine-info {
    display: flex;
    align-items: center;
    gap: 20rpx;
  }
  
  .medicine-quantity {
    font-size: 26rpx;
    color: #666;
  }
  
  .medicine-price {
    font-size: 28rpx;
    color: #ff4d4f;
    font-weight: 600;
    min-width: 100rpx;
    text-align: right;
  }
  
  .footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20rpx;
    box-shadow: 0 -4rpx 12rpx rgba(0,0,0,0.1);
    z-index: 100;
    padding-right: 30rpx;
  }
  
  .footer-left {
    display: flex;
    flex-direction: column;
    gap: 8rpx;
    font-size: 28rpx;
    color: #333;
  }
  
  .total-amount {
    font-size: 24rpx;
    color: #666;
  }
  
  .amount-value {
    font-size: 32rpx;
    font-weight: 600;
    color: #ff4d4f;
  }
  
  .order-btn {
    margin: 0;
    background: #2a82e4;
    color: #fff;
    font-size: 30rpx;
    padding: 0rpx 40rpx;
    border-radius: 50rpx;
    border: none;

  }
  </style>
  