<template>
  <view class="page">
    <view style="padding: 20rpx;">
    <!-- 页面内容 -->
    <scroll-view class="body" scroll-y>
      <!-- 收货地址 -->
      <view class="section address-section" @click="selectAddress">
        <view v-if="selectedAddress" class="address-content">
          <view class="address-header">
            <text class="name">{{ selectedAddress.name }}</text>
            <text class="phone">{{ selectedAddress.phone }}</text>
          </view>
          <view class="address-detail">
            {{ selectedAddress.province }}{{ selectedAddress.city }}{{ selectedAddress.district }}{{ selectedAddress.street }}{{ selectedAddress.detail }}
          </view>
        </view>
        <view v-else class="address-empty">
          <text>请选择收货地址</text>
        </view>
        <view class="address-arrow"><uni-icons type="right" size="24" color="#999"></uni-icons></view>
      </view>
      
      <!-- 配送信息 -->
      <view class="section">
        <view class="section-title">配送信息</view>
        <view class="info-row">
          <text class="label">配送方</text>
          <text class="value">{{ orderInfo.deliveryInfo.distributor }}</text>
        </view>
        <view class="info-row">
          <text class="label">物流公司</text>
          <text class="value">{{ orderInfo.deliveryInfo.logistics }}</text>
        </view>
        <view class="info-row">
          <text class="label">购药方式</text>
          <text class="value">{{ orderInfo.deliveryInfo.purchaseMethod }}</text>
        </view>
        <view class="info-row">
          <text class="label">快递费支付方式</text>
          <text class="value">{{ orderInfo.deliveryInfo.shippingPaymentMethod }}</text>
        </view>
      </view>
      
      <!-- 订单商品 -->
      <view class="section">
        <view class="section-title">订单商品</view>
        <view 
          v-for="item in orderInfo.items" 
          :key="item.id"
          class="order-item"
        >
          <view class="item-info">
            <text class="item-name">{{ item.name }}</text>
            <text class="item-type">{{ item.type }} <text v-if="item.quantity > 1">×{{ item.quantity }}</text></text>
          </view>
          <text class="item-price">¥{{ item.price.toFixed(2) }}</text>
        </view>
      </view>
      
      <!-- 费用明细 -->
      <view class="section">
        <view class="section-title">费用明细</view>
        <view class="cost-row">
          <text class="label">药品费用</text>
          <text class="value">¥{{ orderInfo.cost.medicineCost.toFixed(2) }}</text>
        </view>
        <view class="cost-row">
          <view class="label-with-checkbox">
            <text class="label">代煎</text>
            <view class="checkbox" :class="{ checked: orderInfo.cost.isDecocted }" @click="toggleDecocted"></view>
          </view>
          <text class="value">¥0.00</text>
        </view>
        <view class="cost-row">
          <text class="label">快递费</text>
          <text class="value">¥{{ orderInfo.cost.shippingFee.toFixed(2) }}</text>
        </view>
      </view>
    </scroll-view>
  </view>
    <!-- 底部操作栏 -->
    <view class="footer">
      <view class="footer-left">
        <text class="total-label">合计:</text>
        <text class="total-price">¥{{ orderInfo.total.toFixed(2) }}</text>
      </view>
      <button class="submit-btn" :class="{ disabled: !selectedAddress }" @click="submitOrder">提交订单</button>
    </view>
  </view>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import { 
  STORAGE_KEY_CURRENT_ORDER,
  STORAGE_KEY_SHIPPING_ADDRESSES,
  STORAGE_KEY_DEFAULT_ADDRESS_ID
} from '@/utils/storage.js'
import { loadCartItems, calculateTotalPrice } from '@/utils/cart.js'

const orderInfo = ref({
  prescriptions: [],
  items: [],
  deliveryInfo: {
    distributor: '辽宁中医药大学附属医院',
    logistics: '顺丰快递',
    purchaseMethod: '药品配送-在线支付',
    shippingPaymentMethod: '在线支付'
  },
  cost: {
    medicineCost: 0,
    isDecocted: false,
    shippingFee: 0
  },
  total: 0
})

const addresses = ref([])
const selectedAddress = ref(null)
const categories = ref([])

onMounted(async () => {
  await loadProducts()
  loadOrderInfo()
  loadAddresses()
})

onShow(async () => {
  // 页面显示时检查是否有新选中的地址（从地址选择页面返回）
  const tempAddress = uni.getStorageSync('temp_selected_address')
  if (tempAddress) {
    selectedAddress.value = tempAddress
    uni.removeStorageSync('temp_selected_address')
  } else {
    // 重新加载地址列表（可能地址被编辑或删除）
    loadAddresses()
  }
  
  // 重新加载产品数据并更新订单金额（购物车数据可能已更新）
  if (categories.value.length === 0) {
    await loadProducts()
  }
  loadOrderInfo()
})

// 加载产品数据
const loadProducts = () => {
  return new Promise((resolve) => {
    uni.request({
      url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
      method: 'GET',
      success: (res) => {
        if (res.data && res.data.categories) {
          categories.value = res.data.categories
          resolve(res.data.categories)
        } else {
          resolve([])
        }
      },
      fail: () => {
        // 使用本地备用数据
        const noticeText = '开方前需要先了解该药物是否适合您，请如实填写，以便判断该药物是否适合您\n\n【适应人群】皮肤干燥、口干咽干、容易口渴大便不稀薄的人群\n\n【注意事项】:糖尿病患者及有高血压、心脏病、肝病、肾病等慢性病严重者应在医师指导下用药。'
        const localCategories = [
          {
            id: 'zhou',
            name: '养生粥',
            products: [
              {
                id: 'zhou1',
                name: '养生粥系列一',
                description: '精选优质食材，营养丰富，适合日常养生',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png',
                unit: '1',
                price: 28.00,
                notice: noticeText
              },
              {
                id: 'zhou2',
                name: '养生粥系列二',
                description: '温补养胃，适合脾胃虚弱者',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png',
                unit: '1',
                price: 32.00,
                notice: noticeText
              },
              {
                id: 'zhou3',
                name: '养生粥系列三',
                description: '滋阴润燥，适合秋冬季节',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png',
                unit: '1',
                price: 30.00,
                notice: noticeText
              }
            ]
          },
          {
            id: 'gaoyao',
            name: '辽派滋膏',
            products: [
              {
                id: 'gaoyao1',
                name: '辽派滋膏系列一',
                description: '传统工艺，滋补养生，适合体虚者',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png',
                unit: '1',
                price: 88.00,
                notice: noticeText
              },
              {
                id: 'gaoyao2',
                name: '辽派滋膏系列二',
                description: '精选药材，补气养血，增强体质',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png',
                unit: '1',
                price: 95.00,
                notice: noticeText
              }
            ]
          }
        ]
        categories.value = localCategories
        resolve(localCategories)
      }
    })
  })
}

const loadOrderInfo = () => {
  try {
    const saved = uni.getStorageSync(STORAGE_KEY_CURRENT_ORDER)
    if (saved) {
      orderInfo.value = saved
      
      // 从购物车数据重新计算药品费用
      if (categories.value.length > 0) {
        const cartItems = loadCartItems(categories.value)
        const medicineCost = calculateTotalPrice(cartItems)
        orderInfo.value.cost.medicineCost = parseFloat(medicineCost.toFixed(2))
        
        // 更新订单商品列表（基于购物车数据）
        orderInfo.value.items = cartItems.map(item => ({
          id: item.id,
          name: item.name,
          type: '中药',
          price: parseFloat(((item.price || 0) * (item.quantity || 1)).toFixed(2)),
          quantity: item.quantity || 1
        }))
      }
      
      // 固定快递费为 18 元
      orderInfo.value.cost.shippingFee = 18
      // 计算总价
      calculateTotal()
      // 保存更新后的订单信息
      uni.setStorageSync(STORAGE_KEY_CURRENT_ORDER, orderInfo.value)
    }
  } catch (e) {
    console.error('加载订单信息失败:', e)
    uni.showToast({ title: '加载订单失败', icon: 'none' })
    setTimeout(() => {
      uni.navigateBack()
    }, 1500)
  }
}

const loadAddresses = () => {
  try {
    const saved = uni.getStorageSync(STORAGE_KEY_SHIPPING_ADDRESSES) || []
    addresses.value = saved
    
    // 加载默认地址
    const defaultId = uni.getStorageSync(STORAGE_KEY_DEFAULT_ADDRESS_ID)
    if (defaultId) {
      const defaultAddr = addresses.value.find(a => a.id === defaultId)
      if (defaultAddr) {
        selectedAddress.value = defaultAddr
      }
    } else if (addresses.value.length > 0) {
      // 如果没有默认地址，使用第一个
      selectedAddress.value = addresses.value[0]
    }
  } catch (e) {
    console.error('加载地址列表失败:', e)
  }
}

const calculateTotal = () => {
  let total = orderInfo.value.cost.medicineCost
  if (orderInfo.value.cost.isDecocted) {
    // 代煎费用（示例）
    total += 0
  }
  total += orderInfo.value.cost.shippingFee
  orderInfo.value.total = total
}

const toggleDecocted = () => {
  orderInfo.value.cost.isDecocted = !orderInfo.value.cost.isDecocted
  calculateTotal()
  // 保存订单信息
  uni.setStorageSync(STORAGE_KEY_CURRENT_ORDER, orderInfo.value)
}

const selectAddress = () => {
  uni.navigateTo({
    url: '/pages/order/address_list?select=true'
  })
}

const submitOrder = () => {
  if (!selectedAddress.value) {
    uni.showToast({ title: '请选择收货地址', icon: 'none' })
    return
  }
  
  // 这里应该调用提交订单的API
  // 提交成功后跳转到支付成功页面
  uni.redirectTo({
    url: `/pages/order/payment_success?amount=${orderInfo.value.total}&paymentMethod=${encodeURIComponent(orderInfo.value.deliveryInfo.shippingPaymentMethod)}`
  })
}
</script>

<style scoped>
.page {
  background: #f6f7fb;
  min-height: 100vh;
  padding-bottom: calc(120rpx + env(safe-area-inset-bottom));
}

.body {
  flex: 1;
}

.section {
  background: #fff;
  border-radius: 8rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 30rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 20rpx;
}

.address-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  padding-right: 60rpx;
}

.address-content {
  flex: 1;
}

.address-header {
  display: flex;
  align-items: center;
  gap: 20rpx;
  margin-bottom: 12rpx;
}

.name {
  font-size: 30rpx;
  font-weight: 600;
  color: #333;
}

.phone {
  font-size: 28rpx;
  color: #666;
}

.address-detail {
  font-size: 26rpx;
  color: #666;
  line-height: 1.6;
}

.address-empty {
  flex: 1;
  font-size: 28rpx;
  color: #999;
}

.address-arrow {
  position: absolute;
  right: 20rpx;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
  font-size: 28rpx;
}

.info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}

.info-row:last-child {
  border-bottom: none;
}

.label {
  font-size: 28rpx;
  color: #666;
}

.value {
  font-size: 28rpx;
  color: #333;
}

.order-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}

.order-item:last-child {
  border-bottom: none;
}

.item-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 8rpx;
}

.item-name {
  font-size: 28rpx;
  color: #333;
}

.item-type {
  font-size: 24rpx;
  color: #999;
}

.item-price {
  font-size: 28rpx;
  color: #333;
  font-weight: 600;
}

.cost-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}

.cost-row:last-child {
  border-bottom: none;
}

.label-with-checkbox {
  display: flex;
  align-items: center;
  gap: 12rpx;
}

.checkbox {
  width: 36rpx;
  height: 36rpx;
  border: 2rpx solid #ddd;
  border-radius: 50%;
  position: relative;
}

.checkbox.checked {
  background: #2a82e4;
  border-color: #2a82e4;
}

.checkbox.checked::after {
  content: '✓';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #fff;
  font-size: 24rpx;
}

.footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx;
  padding-bottom: calc(20rpx + env(safe-area-inset-bottom));
  box-shadow: 0 -4rpx 12rpx rgba(0,0,0,0.1);
  z-index: 100;
}

.footer-left {
  display: flex;
  align-items: baseline;
  gap: 8rpx;
}

.total-label {
  font-size: 28rpx;
  color: #666;
}

.total-price {
  font-size: 36rpx;
  font-weight: 600;
  color: #ff4d4f;
}

.submit-btn {
  background: #2a82e4;
  color: #fff;
  font-size: 30rpx;
  padding: 0rpx 40rpx;
  border-radius: 50rpx;
  border: none;
  margin: 0;

}

.submit-btn.disabled {
  background: #ccc;
  color: #999;
  pointer-events: auto;
}
</style>

