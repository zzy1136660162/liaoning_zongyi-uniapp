<template>
  <view class="page">
    <view class="content">
      <!-- 成功图标和文字 -->
      <view class="success-header">
        <view class="success-icon-wrapper">
          <view class="success-icon">
            <uni-icons type="checkmarkempty" size="80" color="#07c160"></uni-icons>
          </view>
        </view>
        <text class="success-text">支付成功</text>
      </view>
      
      <!-- 支付金额 -->
      <view class="amount-section">
        <text class="amount-label">支付金额</text>
        <text class="amount-value">¥{{ paymentInfo.amount.toFixed(2) }}</text>
      </view>
      
      <!-- 支付信息卡片 -->
      <view class="info-card">
        <view class="info-row">
          <text class="info-label">支付方式</text>
          <text class="info-value">{{ paymentInfo.paymentMethod }}</text>
        </view>
        <view class="info-row">
          <text class="info-label">订单号</text>
          <text class="info-value order-no">{{ paymentInfo.orderNo }}</text>
        </view>
        <view class="info-row">
          <text class="info-label">支付时间</text>
          <text class="info-value">{{ paymentInfo.paymentTime }}</text>
        </view>
      </view>
      
      <!-- 提示信息 -->
      <view class="tip-section">
        <text class="tip-text">订单已提交，我们将尽快为您处理</text>
      </view>
    </view>
    
    <!-- 底部按钮 -->
    <view class="footer">
      <button class="complete-btn" @click="goHome">完成</button>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { STORAGE_KEY_CURRENT_ORDER } from '@/utils/storage.js'
import { loadCartItems, calculateTotalPrice } from '@/utils/cart.js'

const paymentInfo = ref({
  amount: 0,
  paymentMethod: '在线支付',
  orderNo: '',
  paymentTime: ''
})

const categories = ref([])

// 生成订单号
const generateOrderNo = () => {
  const timestamp = Date.now()
  const random = Math.floor(Math.random() * 10000)
  return `ORD${timestamp}${random.toString().padStart(4, '0')}`
}

// 格式化时间
const formatTime = (date = new Date()) => {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')
  const second = String(date.getSeconds()).padStart(2, '0')
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`
}

// 加载产品数据
const loadProducts = () => {
  return new Promise((resolve) => {
    uni.request({
      url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
      method: 'GET',
      success: (res) => {
        if (res.data && res.data.categories) {
          categories.value = res.data.categories
          resolve(res.data.categories)
        } else {
          resolve([])
        }
      },
      fail: () => {
        // 使用本地备用数据
        const noticeText = '开方前需要先了解该药物是否适合您，请如实填写，以便判断该药物是否适合您\n\n【适应人群】皮肤干燥、口干咽干、容易口渴大便不稀薄的人群\n\n【注意事项】:糖尿病患者及有高血压、心脏病、肝病、肾病等慢性病严重者应在医师指导下用药。'
        const localCategories = [
          {
            id: 'zhou',
            name: '养生粥',
            products: [
              {
                id: 'zhou1',
                name: '养生粥系列一',
                description: '精选优质食材，营养丰富，适合日常养生',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png',
                unit: '1',
                price: 28.00,
                notice: noticeText
              },
              {
                id: 'zhou2',
                name: '养生粥系列二',
                description: '温补养胃，适合脾胃虚弱者',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png',
                unit: '1',
                price: 32.00,
                notice: noticeText
              },
              {
                id: 'zhou3',
                name: '养生粥系列三',
                description: '滋阴润燥，适合秋冬季节',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png',
                unit: '1',
                price: 30.00,
                notice: noticeText
              }
            ]
          },
          {
            id: 'gaoyao',
            name: '辽派滋膏',
            products: [
              {
                id: 'gaoyao1',
                name: '辽派滋膏系列一',
                description: '传统工艺，滋补养生，适合体虚者',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png',
                unit: '1',
                price: 88.00,
                notice: noticeText
              },
              {
                id: 'gaoyao2',
                name: '辽派滋膏系列二',
                description: '精选药材，补气养血，增强体质',
                image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png',
                unit: '1',
                price: 95.00,
                notice: noticeText
              }
            ]
          }
        ]
        categories.value = localCategories
        resolve(localCategories)
      }
    })
  })
}

onLoad(async (options) => {
  // 加载产品数据
  await loadProducts()
  
  // 从购物车数据计算金额
  let calculatedAmount = 0
  try {
    const cartItems = loadCartItems(categories.value)
    const cartTotal = calculateTotalPrice(cartItems)
    
    // 尝试从订单信息获取快递费
    const orderInfo = uni.getStorageSync(STORAGE_KEY_CURRENT_ORDER)
    if (orderInfo && orderInfo.cost) {
      // 药品费用 + 快递费
      calculatedAmount = cartTotal + (orderInfo.cost.shippingFee || 18)
    } else {
      // 如果没有订单信息，只计算药品费用
      calculatedAmount = cartTotal
    }
  } catch (e) {
    console.error('计算购物车金额失败:', e)
  }
  
  // 优先使用页面参数，其次使用购物车计算的金额，最后使用订单信息
  if (options.amount) {
    paymentInfo.value.amount = parseFloat(options.amount)
  } else if (calculatedAmount > 0) {
    paymentInfo.value.amount = parseFloat(calculatedAmount.toFixed(2))
  } else {
    // 如果没有传递金额，尝试从存储中获取
    try {
      const orderInfo = uni.getStorageSync(STORAGE_KEY_CURRENT_ORDER)
      if (orderInfo && orderInfo.total) {
        paymentInfo.value.amount = orderInfo.total
      }
    } catch (e) {
      console.error('获取订单信息失败:', e)
    }
  }
  
  // 生成订单号和支付时间
  paymentInfo.value.orderNo = generateOrderNo()
  paymentInfo.value.paymentTime = formatTime()
  
  // 如果有传递支付方式，使用传递的值
  if (options.paymentMethod) {
    paymentInfo.value.paymentMethod = decodeURIComponent(options.paymentMethod)
  }
})

const goHome = () => {
  // 跳转到产品列表页面
  uni.redirectTo({
    url: '/pages/products/priducts_list'
  })
}
</script>

<style scoped>
.page {
  background: #f6f7fb;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  padding-bottom: calc(120rpx + env(safe-area-inset-bottom));
}

.content {
  flex: 1;
  padding: 60rpx 40rpx;
}

.success-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 80rpx;
  padding-top: 40rpx;
}

.success-icon-wrapper {
  margin-bottom: 40rpx;
}

.success-icon {
  width: 160rpx;
  height: 160rpx;
  border-radius: 50%;
  background: linear-gradient(135deg, #e8f8f0 0%, #d4f4e0 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8rpx 24rpx rgba(7, 193, 96, 0.15);
  animation: scaleIn 0.5s ease-out;
}

@keyframes scaleIn {
  0% {
    transform: scale(0);
    opacity: 0;
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

.success-text {
  font-size: 38rpx;
  font-weight: 600;
  color: #333;
  letter-spacing: 2rpx;
}

.amount-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 80rpx;
  padding: 40rpx 0;
}

.amount-label {
  font-size: 28rpx;
  color: #999;
  margin-bottom: 24rpx;
}

.amount-value {
  font-size: 80rpx;
  font-weight: 600;
  color: #333;
  letter-spacing: 4rpx;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
}

.info-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 40rpx;
  margin-bottom: 40rpx;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.04);
}

.info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}

.info-row:last-child {
  border-bottom: none;
}

.info-label {
  font-size: 28rpx;
  color: #666;
}

.info-value {
  font-size: 28rpx;
  color: #333;
  font-weight: 500;
}

.order-no {
  font-family: 'Courier New', monospace;
  letter-spacing: 2rpx;
}

.tip-section {
  text-align: center;
  padding: 20rpx 0;
}

.tip-text {
  font-size: 26rpx;
  color: #999;
  line-height: 1.6;
}

.footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  padding: 30rpx 40rpx;
  padding-bottom: calc(30rpx + env(safe-area-inset-bottom));
  box-shadow: 0 -4rpx 12rpx rgba(0,0,0,0.05);
}

.complete-btn {
  width: 100%;
  background: #07c160;
  color: #fff;
  font-size: 32rpx;
  font-weight: 600;
  padding: 24rpx 0;
  border-radius: 50rpx;
  border: none;
  margin: 0;
}

.complete-btn::after {
  border: none;
}
</style>

