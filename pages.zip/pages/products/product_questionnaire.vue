<template>
	<view class="questionnaire-container">
		<view class="content-section" v-if="questions && questions.length > 0">
			<view 
				class="question-item" 
				v-for="(question, index) in questions" 
				:key="'question-' + index"
			>
				<view class="question-header">
					<text class="question-label">Q{{ index + 1 }}. {{ question.text }}</text>
					<text class="question-type">单选</text>
				</view>
				<view class="options">
					<view 
						class="option-item" 
						v-for="(option, optIndex) in question.options" 
						:key="'option-' + index + '-' + optIndex"
						:class="{ active: question.answer === option.value }"
						@click="selectAnswer(index, option.value)"
					>
						<view class="radio">
							<view class="radio-inner" v-if="question.answer === option.value"></view>
						</view>
						<text class="option-text">{{ option.label }}</text>
					</view>
				</view>
			</view>
			
			<view class="question-count">- 共{{ questions.length }}题 -</view>
			
			<view class="button-group">
				<button class="save-btn" @click="saveDraft">暂存</button>
				<button class="submit-btn" @click="submitAnswer">提交</button>
			</view>
		</view>
	</view>
</template>

<script>
import { STORAGE_KEY_VERIFIED_PRODUCTS, STORAGE_KEY_PRODUCT_QUANTITIES } from '@/utils/storage.js'

export default {
	data() {
		return {
			productId: '',
			questions: [
				{
					text: '是否容易心烦急躁',
					options: [
						{ label: '是', value: 'yes' },
						{ label: '否', value: 'no' }
					],
					answer: null
				},
				{
					text: '是否有口干口苦等症状',
					options: [
						{ label: '是', value: 'yes' },
						{ label: '否', value: 'no' }
					],
					answer: null
				},
				{
					text: '大便干结等症状',
					options: [
						{ label: '是', value: 'yes' },
						{ label: '否', value: 'no' }
					],
					answer: null
				},
				{
					text: '是否有手两足心发热,并自觉心胸烦热等症状',
					options: [
						{ label: '是', value: 'yes' },
						{ label: '否', value: 'no' }
					],
					answer: null
				},
				{
					text: '是否有对中药过敏的过敏史',
					options: [
						{ label: '是', value: 'yes' },
						{ label: '否', value: 'no' }
					],
					answer: null
				}
			]
		}
	},
	onLoad(options) {
		this.productId = options.id || ''
		// 确保数据正确初始化
		console.log('Questions loaded:', this.questions.length)
	},
	methods: {
		selectAnswer(questionIndex, value) {
			this.questions[questionIndex].answer = value
		},
		saveDraft() {
			uni.showToast({
				title: '已暂存',
				icon: 'success'
			})
		},
		saveVerifiedProduct() {
			// 从 uniStorage 读取已验证的产品列表
			let verifiedProducts = uni.getStorageSync(STORAGE_KEY_VERIFIED_PRODUCTS) || {}
			let productQuantities = uni.getStorageSync(STORAGE_KEY_PRODUCT_QUANTITIES) || {}
			
			// 添加当前产品
			verifiedProducts[this.productId] = true
			// 如果产品已存在，保持原有数量；否则初始化为1
			if (!productQuantities[this.productId]) {
				productQuantities[this.productId] = 1
			}
			
			// 保存到 uniStorage
			uni.setStorageSync(STORAGE_KEY_VERIFIED_PRODUCTS, verifiedProducts)
			uni.setStorageSync(STORAGE_KEY_PRODUCT_QUANTITIES, productQuantities)
			
			console.log('产品验证状态已保存:', this.productId)
		},
		submitAnswer() {
			// 检查是否所有题目都已作答
			const allAnswered = this.questions.every(q => q.answer !== null)
			if (!allAnswered) {
				uni.showToast({
					title: '请完成所有题目',
					icon: 'none'
				})
				return
			}
			
			// 判断是否符合病症
			// 根据图片示例，判断逻辑应该是：
			// Q1-Q3 选择"是"，Q4-Q5 选择"否" 才符合
			const isSuitable = 
				this.questions[0].answer === 'yes' &&
				this.questions[1].answer === 'yes' &&
				this.questions[2].answer === 'yes' &&
				this.questions[3].answer === 'no' &&
				this.questions[4].answer === 'no'
			
			if (!isSuitable) {
				// 不符合，弹出提示
				uni.showModal({
					title: '提示',
					content: '考虑到您当前的情况，暂时不推荐使用，建议您去医院就诊',
					showCancel: false,
					confirmText: '确定',
					success: (res) => {
						if (res.confirm) {
							// 返回上一页
							uni.navigateBack()
						}
					}
				})
			} else {
				// 符合条件，保存到 uniStorage 并返回列表页
				this.saveVerifiedProduct()
				
				uni.showToast({
					title: '症状符合药方',
					icon: 'success'
				})
				
				// 通过页面栈返回并传递参数
				setTimeout(() => {
					const pages = getCurrentPages()
					// 找到列表页面（注意页面和列表页面）
					for (let i = pages.length - 1; i >= 0; i--) {
						const page = pages[i]
						// 检查是否是列表页面
						if (page.route && page.route.includes('priducts_list')) {
							// 设置产品验证状态
							if (page.setProductVerified) {
								page.setProductVerified(this.productId, true)
							}
							break
						}
					}
					// 返回到列表页（跳过注意页面）
					uni.navigateBack({
						delta: 2
					})
				}, 1500)
			}
		}
	}
}
</script>

<style scoped>
.questionnaire-container {
	width: 100%;
	min-height: 100vh;
	background-color: #ffffff;
	display: flex;
	flex-direction: column;
}

.content-section {
	padding: 40rpx 30rpx;
	flex: 1;
}

.question-item {
	margin-bottom: 50rpx;
}

.question-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 20rpx;
}

.question-label {
	font-size: 30rpx;
	font-weight: 500;
	color: #333333;
}

.question-type {
	font-size: 24rpx;
	color: #FFB6C1;
	background-color: #FFF0F5;
	padding: 4rpx 12rpx;
	border-radius: 8rpx;
}

.options {
	display: flex;
	flex-direction: column;
}

.options .option-item {
	margin-bottom: 20rpx;
}

.options .option-item:last-child {
	margin-bottom: 0;
}

.option-item {
	display: flex;
	align-items: center;
	padding: 20rpx;
	background-color: #f9f9f9;
	border-radius: 12rpx;
	transition: all 0.3s;
}

.option-item.active {
	background-color: #FFF0F5;
}

.radio {
	width: 40rpx;
	height: 40rpx;
	border: 2rpx solid #cccccc;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-right: 20rpx;
	transition: all 0.3s;
}

.option-item.active .radio {
	border-color: #FFB6C1;
}

.radio-inner {
	width: 24rpx;
	height: 24rpx;
	background-color: #FFB6C1;
	border-radius: 50%;
}

.option-text {
	font-size: 28rpx;
	color: #333333;
}

.question-count {
	text-align: center;
	font-size: 24rpx;
	color: #999999;
	margin: 40rpx 0;
}

.button-group {
	display: flex;
	margin-top: 40rpx;
}

.button-group .save-btn {
	margin-right: 20rpx;
}

.button-group .submit-btn {
	margin-left: 0;
}

.save-btn,
.submit-btn {
	flex: 1;
	height: 88rpx;
	border-radius: 44rpx;
	font-size: 30rpx;
	border: none;
	display: flex;
	align-items: center;
	justify-content: center;
}

.save-btn {
	background-color: #FFF0F5;
	color: #FFB6C1;
}

.submit-btn {
	background: linear-gradient(135deg, #FFB6C1 0%, #FFC0CB 100%);
	color: #ffffff;
	font-weight: 500;
}
</style>

