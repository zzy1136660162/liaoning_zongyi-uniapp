<template>
	<view class="product-container">
		 
		
		<!-- Banner区域 -->
		<view class="banner-section">
			<image class="banner-image" src="https://yuntuoengine.com/assets_files/liaoning_zongyi/banner_bg.png" mode="widthFix"></image>
		</view>
		
		<!-- 搜索栏 -->
		<view class="search-section">
			<view class="search-bar">
				<uni-icons type="search" size="18" color="#999999"></uni-icons>
				<input class="search-input" placeholder="搜索" v-model="searchKeyword" @input="handleSearch" />
				<button class="search-btn" @click="handleSearch">搜索</button>
			</view>
		</view>
		 <!-- 列表头部 -->
         <view class="product-list-header">
					<view class="prescription-title">
						<text class="prescription-text">药方</text>
					</view>
					<view class="history-order" @click="goToHistory">
						<uni-icons type="list" size="18" color="#666666"></uni-icons>
						<text class="history-text">历史订单</text>
					</view>
				</view>
		<!-- 主要内容区域 -->
		<view class="main-content">
           
			<!-- 左侧分类导航 -->
			<scroll-view class="category-nav" scroll-y>
				<view 
					class="category-item" 
					v-for="(category, index) in categories" 
					:key="category.id"
					:class="{ active: currentCategoryId === category.id }"
					@click="switchCategory(category.id)"
				>
					<text class="category-name">{{ category.name }}</text>
				</view>
			</scroll-view>
			
			<!-- 右侧产品列表 -->
			<view class="product-list-wrapper">
				
				<scroll-view class="product-list" scroll-y>
					<view class="product-items">
					<view 
						class="product-item" 
						v-for="(product, productIndex) in filteredProducts" 
						:key="product.id"
					>
						<image class="product-image" :src="product.image" mode="aspectFill" @click="goToDetail(product)"></image>
						<view class="product-info">
							<text class="product-name" @click="goToDetail(product)">{{ product.name }}</text>
							<text class="product-desc" v-if="product.description">{{ product.description }}</text>
							<view class="product-footer">
								<text class="product-unit">{{ product.unit }}</text>
								<view class="product-price-row">
									<!-- 如果产品已通过验证，显示数量选择器 -->
									<view v-if="isProductVerified(product.id)" class="quantity-selector">
										<button class="quantity-btn" @click="decreaseQuantity(product)">-</button>
										<text class="quantity-text">{{ getProductQuantity(product.id) }}</text>
										<button class="quantity-btn" @click="increaseQuantity(product)">+</button>
									</view>
									<!-- 否则显示价格和选择按钮 -->
									<template v-else>
										<text class="product-price">¥{{ product.price.toFixed(2) }}</text>
										<button 
											class="select-btn" 
											:id="`select-btn-${product.id}`"
											@click="goToNotice(product)"
										>选择</button>
									</template>
								</view>
							</view>
						</view>
					</view>
					</view>
				</scroll-view>
			</view>
		</view>
		
		<!-- 底部购物车栏 -->
		<view class="cart-bar">
			<view class="cart-icon-wrapper" @click="showCart" id="cart-icon-target">
				<view class="cart-icon">
					<uni-icons type="cart" size="30" color="#ffffff"></uni-icons>
				</view>
				<view class="cart-badge" v-if="cartCount > 0">{{ cartCount }}</view>
			</view>
			<view class="cart-info">
				<text class="cart-total">¥ {{ totalPrice.toFixed(2) }}</text>
				<text class="cart-tip">不含复诊费,实际金额以结算为准</text>
			</view>
			<button class="submit-btn" @click="handleSubmit">提&nbsp;交</button>
		</view>
		
		<!-- 动画小球 -->
		<view 
			class="fly-ball" 
			v-if="showFlyBall"
			:style="{
				left: flyBallStyle.left + 'px',
				top: flyBallStyle.top + 'px',
				transform: `translate(-50%, -50%) scale(${flyBallStyle.scale})`
			}"
		></view>
	</view>
</template>

<script>
import { 
	STORAGE_KEY_VERIFIED_PRODUCTS, 
	STORAGE_KEY_PRODUCT_QUANTITIES,
	STORAGE_KEY_USER_REGISTER 
} from '@/utils/storage.js'

export default {
	data() {
		return {
			searchKeyword: '',
			currentCategoryId: 'gaoyao',
			categories: [],
			allProducts: [],
			cartItems: [],
			productsData: null,
			showFlyBall: false,
			flyBallStyle: {
				left: 0,
				top: 0,
				scale: 1
			},
			verifiedProducts: {}, // 存储已通过验证的产品ID
			productQuantities: {} // 存储产品的数量
		}
	},
	computed: {
		filteredProducts() {
			const category = this.categories.find(cat => cat.id === this.currentCategoryId)
			if (!category) return []
			
			let products = category.products || []
			
			// 搜索过滤
			if (this.searchKeyword.trim()) {
				const keyword = this.searchKeyword.trim().toLowerCase()
				products = products.filter(product => 
					product.name.toLowerCase().includes(keyword) ||
					(product.description && product.description.toLowerCase().includes(keyword))
				)
			}
			
			return products
		},
		cartCount() {
			return this.cartItems.reduce((total, item) => total + item.quantity, 0)
		},
		totalPrice() {
			return this.cartItems.reduce((total, item) => total + (item.price * item.quantity), 0)
		}
	},
	onLoad() {
		this.loadProducts()
	},
	onShow() {
		// 页面显示时，重新加载已验证的产品数据
		this.loadVerifiedProductsFromStorage()
	},
	methods: {
		loadProducts() {
			// 加载产品数据
			uni.request({
				url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
				method: 'GET',
				success: (res) => {
					if (res.data && res.data.categories) {
						this.productsData = res.data
						// 对分类进行排序，确保 'gaoyao' (辽派膏滋) 在 'zhou' (养生粥) 前面
						this.categories = res.data.categories 
						// 默认选中第一个分类
						if (this.categories.length > 0) {
							this.currentCategoryId = this.categories[0].id
						}
						// 产品数据加载完成后，加载已验证的产品
						this.loadVerifiedProductsFromStorage()
					}
				},
				fail: (err) => {
					console.error('加载产品数据失败:', err)
					// 如果请求失败，使用本地数据
					this.loadLocalData()
					// 本地数据加载完成后，加载已验证的产品
					this.loadVerifiedProductsFromStorage()
				}
			})
		},
		loadVerifiedProductsFromStorage() {
			// 从 uniStorage 读取已验证的产品和数量
			try {
				const verifiedProducts = uni.getStorageSync(STORAGE_KEY_VERIFIED_PRODUCTS) || {}
				const productQuantities = uni.getStorageSync(STORAGE_KEY_PRODUCT_QUANTITIES) || {}
				
				// 更新数据
				this.verifiedProducts = verifiedProducts
				this.productQuantities = productQuantities
				
				// 更新购物车
				this.updateCartFromStorage()
				
				console.log('已验证产品已加载:', Object.keys(verifiedProducts).length)
			} catch (e) {
				console.error('加载已验证产品失败:', e)
			}
		},
		updateCartFromStorage() {
			// 根据已验证的产品和数量更新购物车
			this.cartItems = []
			for (let productId in this.verifiedProducts) {
				if (this.verifiedProducts[productId]) {
					// 找到产品信息
					let product = null
					for (let category of this.categories) {
						product = category.products.find(p => p.id === productId)
						if (product) break
					}
					
					if (product) {
						const quantity = this.productQuantities[productId] || 1
						this.cartItems.push({
							...product,
							quantity: quantity
						})
					}
				}
			}
		},
		loadLocalData() {
			// 本地数据作为备用
			const noticeText = '开方前需要先了解该药物是否适合您，请如实填写，以便判断该药物是否适合您\n\n【适应人群】皮肤干燥、口干咽干、容易口渴大便不稀薄的人群\n\n【注意事项】:糖尿病患者及有高血压、心脏病、肝病、肾病等慢性病严重者应在医师指导下用药。'
			
			this.categories = [
				{
					id: 'gaoyao',
					name: '辽派滋膏',
					products: [
						{
							id: 'gaoyao1',
							name: '辽派滋膏系列一',
							description: '传统工艺，滋补养生，适合体虚者',
							image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao1.png',
							unit: '1帖',
							price: 88.00,
							notice: noticeText
						},
						{
							id: 'gaoyao2',
							name: '辽派滋膏系列二',
							description: '精选药材，补气养血，增强体质',
							image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_gaoyao2.png',
							unit: '1帖',
							price: 95.00,
							notice: noticeText
						}
					]
				},
				{
					id: 'zhou',
					name: '养生粥',
					products: [
						{
							id: 'zhou1',
							name: '养生粥系列一',
							description: '精选优质食材，营养丰富，适合日常养生',
							image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou1.png',
							unit: '1帖',
							price: 28.00,
							notice: noticeText
						},
						{
							id: 'zhou2',
							name: '养生粥系列二',
							description: '温补养胃，适合脾胃虚弱者',
							image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou2.png',
							unit: '1帖',
							price: 32.00,
							notice: noticeText
						},
						{
							id: 'zhou3',
							name: '养生粥系列三',
							description: '滋阴润燥，适合秋冬季节',
							image: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_zhou3.png',
							unit: '1帖',
							price: 30.00,
							notice: noticeText
						}
					]
				}
			]
			this.currentCategoryId = 'gaoyao'
		},
		switchCategory(categoryId) {
			this.currentCategoryId = categoryId
		},
		handleSearch() {
			// 搜索功能已在computed中实现
		},
		goToDetail(product) {
			// 跳转到详情页面，传递产品信息
			// 将产品信息序列化后传递
			const productData = encodeURIComponent(JSON.stringify({
				id: product.id,
				name: product.name,
				price: product.price,
				image: product.image,
				description: product.description,
				unit: product.unit
			}))
			uni.navigateTo({
				url: `/pages/products/priducts_detail?product=${productData}`
			})
		},
		goToNotice(product) {
			// 跳转到注意页面
			uni.navigateTo({
				url: `/pages/products/product_notice?id=${product.id}`
			})
		},
		setProductVerified(productId, verified) {
			// 设置产品验证状态
			if (verified) {
				this.$set(this.verifiedProducts, productId, true)
				// 如果数量不存在，初始化为1
				if (!this.productQuantities[productId]) {
					this.$set(this.productQuantities, productId, 1)
				}
				// 保存到 uniStorage
				this.saveVerifiedProductsToStorage()
				// 添加到购物车
				this.addToCartAfterVerified(productId)
			}
		},
		saveVerifiedProductsToStorage() {
			// 保存已验证产品和数量到 uniStorage
			try {
				uni.setStorageSync(STORAGE_KEY_VERIFIED_PRODUCTS, this.verifiedProducts)
				uni.setStorageSync(STORAGE_KEY_PRODUCT_QUANTITIES, this.productQuantities)
			} catch (e) {
				console.error('保存已验证产品失败:', e)
			}
		},
		isProductVerified(productId) {
			return this.verifiedProducts[productId] === true
		},
		getProductQuantity(productId) {
			return this.productQuantities[productId] || 0
		},
		increaseQuantity(product) {
			const current = Number(this.productQuantities[product.id] || 0)
			const newQty = current + 1
			this.$set(this.productQuantities, product.id, newQty)
			// 保存到 uniStorage
			this.saveVerifiedProductsToStorage()
			// 更新购物车
			this.updateCartItem(product, newQty)
		},
		decreaseQuantity(product) {
			console.log(product);
			
			const current = Number(this.productQuantities[product.id] || 0)
			console.log('current', current);
			
			if (current <= 0) return
			
			if (current > 1) {
				const newQty = current - 1
				console.log('newQty', newQty);
				
				this.$set(this.productQuantities, product.id, newQty)
				// 保存到 uniStorage
				this.saveVerifiedProductsToStorage()
				// 更新购物车
				this.updateCartItem(product, newQty)
		} else { // current === 1
			console.log('进入删除分支，current === 1:', current === 1);
			console.log('product.id:', product.id);
			
			try {
				// 数量从1减到0，移除产品验证状态
				if (this.verifiedProducts.hasOwnProperty(product.id)) {
					// 使用兼容方式删除响应式对象属性
					delete this.verifiedProducts[product.id]
					// 重新赋值以触发响应式更新
					this.verifiedProducts = { ...this.verifiedProducts }
					console.log('已删除 verifiedProducts:', product.id);
				}
				if (this.productQuantities.hasOwnProperty(product.id)) {
					// 使用兼容方式删除响应式对象属性
					delete this.productQuantities[product.id]
					// 重新赋值以触发响应式更新
					this.productQuantities = { ...this.productQuantities }
					console.log('已删除 productQuantities:', product.id);
				}
				
				console.log('准备调用 removeFromCart, product.id:', product.id);
				
				// 从购物车中移除
				this.removeFromCart(product.id)
				
				// 保存到 uniStorage
				this.saveVerifiedProductsToStorage()
				
				console.log('删除流程完成');
			} catch (e) {
				console.error('删除产品时出错:', e);
			}
		}
		},
		updateCartItem(product, quantity) {
			const existingItem = this.cartItems.find(item => item.id === product.id)
			if (existingItem) {
				existingItem.quantity = quantity
			} else {
				this.cartItems.push({
					...product,
					quantity: quantity
				})
			}
		},
		removeFromCart(productId) {
			const index = this.cartItems.findIndex(item => item.id === productId)
			console.log('removeFromCart', index);
			
			if (index > -1) {
				this.cartItems.splice(index, 1)
			}
		},
		addToCartAfterVerified(productId) {
			// 找到产品
			let product = null
			for (let category of this.categories) {
				product = category.products.find(p => p.id === productId)
				if (product) break
			}
			
			if (product) {
				const existingItem = this.cartItems.find(item => item.id === product.id)
				if (existingItem) {
					existingItem.quantity = this.productQuantities[productId] || 1
				} else {
					this.cartItems.push({
						...product,
						quantity: this.productQuantities[productId] || 1
					})
				}
			}
		},
		directAddToCart(product) {
			const existingItem = this.cartItems.find(item => item.id === product.id)
			if (existingItem) {
				existingItem.quantity += 1
			} else {
				this.cartItems.push({
					...product,
					quantity: 1
				})
			}
			uni.showToast({
				title: '已添加到购物车',
				icon: 'success',
				duration: 1500
			})
		},
		showCart() {
			// 显示购物车详情（可以后续扩展）
			uni.showToast({
				title: `购物车中有${this.cartCount}件商品`,
				icon: 'none'
			})
		},
		handleSubmit() {
			if (this.cartItems.length === 0) {
				uni.showToast({
					title: '请先选择商品',
					icon: 'none'
				})
				return
			}
			
			// 检查是否已注册
			try {
				const userRegisterInfo = uni.getStorageSync(STORAGE_KEY_USER_REGISTER)
				if (!userRegisterInfo || !userRegisterInfo.realName) {
					// 未注册，跳转到注册页面，传递 redirect 参数
					uni.navigateTo({
						url: '/pages/register/register?redirect=/pages/dispense/apply'
					})
					return
				}
				
				// 已注册，跳转到申请页面
				uni.navigateTo({
					url: '/pages/dispense/apply'
				})
			} catch (e) {
				console.error('检查注册状态失败:', e)
				// 出错时也跳转到注册页面，传递 redirect 参数
				uni.navigateTo({
					url: '/pages/register/register?redirect=/pages/dispense/apply'
				})
			}
		},
		goToHistory() {
			// 跳转回列表视图（priducts_list.vue）
			uni.redirectTo({
				url: '/pages/products/priducts_list'
			})
		},
		goBack() {
			uni.navigateBack()
		}
	}
}
</script>

<style scoped>
.product-container {
	width: 100%;
	min-height: 100vh;
	background-color: #f5f5f5;
	padding-bottom: calc(120rpx + env(safe-area-inset-bottom));
}

.nav-bar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 88rpx;
	padding: 0 30rpx;
	background-color: #ffffff;
	border-bottom: 1rpx solid #e5e5e5;
}

.nav-left,
.nav-right {
	width: 60rpx;
	height: 60rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}

.nav-icon {
	font-size: 36rpx;
	color: #333333;
}

.nav-title {
	font-size: 36rpx;
	font-weight: 500;
	color: #333333;
}

.banner-section {
	width: 100%;
	margin-bottom: 20rpx;
	overflow: hidden;
}

.banner-image {
	width: 100%;
	height: auto;
	display: block;
}

.banner-content {
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.hospital-info {
	flex: 1;
}

.hospital-name {
	display: block;
	font-size: 32rpx;
	font-weight: bold;
	color: #333333;
	margin-bottom: 10rpx;
}

.hospital-subtitle {
	display: block;
	font-size: 28rpx;
	color: #666666;
}

.banner-right {
	display: flex;
	flex-direction: column;
	align-items: flex-end;
}

.doctor-illustration {
	position: relative;
	margin-bottom: 20rpx;
}

.doctor-img {
	width: 120rpx;
	height: 120rpx;
}

.recommend-tag {
	position: absolute;
	top: -20rpx;
	right: -20rpx;
	background-color: #ffd700;
	color: #333333;
	font-size: 20rpx;
	padding: 8rpx 16rpx;
	border-radius: 20rpx;
	white-space: nowrap;
}

.consult-btn {
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 24rpx;
	padding: 12rpx 24rpx;
	border-radius: 30rpx;
	border: none;
}

.search-section {
	padding: 20rpx 30rpx;
	background-color: #ffffff;
}

.search-bar {
	display: flex;
	align-items: center;
	background-color: #f5f5f5;
	border-radius: 50rpx;
	padding: 10rpx 10rpx 10rpx 30rpx;
	position: relative;
}

.search-bar uni-icons {
	margin-right: 20rpx;
}

.search-input {
	flex: 1;
	font-size: 28rpx;
	color: #333333;
	padding-right: 10rpx;
}

.search-btn {
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 26rpx;
	padding: 0rpx 24rpx;
	border-radius: 40rpx;
	border: none;
	margin-left: 10rpx;
	flex-shrink: 0;
}

.main-content {
	display: flex;
	height: calc(100vh - 400rpx);
}

.category-nav {
	width: 200rpx;
	background-color: #ffffff;
	border-right: 1rpx solid #e5e5e5;
}

.category-item {
	padding: 30rpx 20rpx;
	text-align: center;
	border-left: 4rpx solid transparent;
	transition: all 0.3s;
}

.category-item.active {
	background-color: #f0f8ff;
	border-left-color: #4A90E2;
}

.category-item.active .category-name {
	color: #4A90E2;
	font-weight: 500;
}

.category-name {
	font-size: 28rpx;
	color: #666666;
}

.product-list-wrapper {
	padding: 20rpx;
	flex: 1;
	background-color: #ffffff;
	display: flex;
	flex-direction: column;
}

.product-list-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 20rpx 20rpx 16rpx 20rpx;
	border-bottom: 1rpx solid #f0f0f0;
}

.prescription-title {
	display: flex;
	align-items: center;
}

.prescription-text {
	font-size: 32rpx;
	font-weight: 600;
	background: #333;
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	background-clip: text;
	text-shadow: 0 2rpx 4rpx rgba(74, 144, 226, 0.2);
	position: relative;
	padding-left: 12rpx;
}

.prescription-text::before {
	content: '';
	position: absolute;
	left: 0;
	top: 50%;
	transform: translateY(-50%);
	width: 6rpx;
	height: 24rpx;
	background: linear-gradient(135deg, #4A90E2 0%, #6BB3FF 100%);
	border-radius: 3rpx;
	box-shadow: 0 2rpx 8rpx rgba(74, 144, 226, 0.3);
}

.history-order {
	display: flex;
	align-items: center;
	gap: 8rpx;
	padding: 8rpx 16rpx;
	border-radius: 30rpx;
	transition: all 0.3s;
}

.history-order:active {
	background-color: #f5f5f5;
}

.history-text {
	font-size: 26rpx;
	color: #666666;
}

.product-list {
	flex: 1;
}

.product-header {
	display: flex;
	justify-content: flex-end;
	margin-bottom: 20rpx;
}

.history-btn {
	background-color: #ffffff;
	color: #666666;
	font-size: 26rpx;
	padding: 10rpx 20rpx;
	border: 1rpx solid #e5e5e5;
	border-radius: 20rpx;
}

.product-items {
	display: flex;
	flex-direction: column;
	gap: 30rpx;
}

.product-item {
	display: flex;
	background-color: #ffffff;
	border-radius: 16rpx;
	overflow: hidden;
	box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.product-image {
	width: 200rpx;
	height: 200rpx;
	flex-shrink: 0;
	background-color: #f5f5f5;
	cursor: pointer;
}

.product-info {
	flex: 1;
	padding: 20rpx;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
}

.product-name {
	font-size: 30rpx;
	font-weight: 500;
	color: #333333;
	margin-bottom: 10rpx;
	display: block;
	cursor: pointer;
}

.product-desc {
	font-size: 24rpx;
	color: #999999;
	margin-bottom: 20rpx;
	display: block;
	line-height: 1.5;
}

.product-footer {
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.product-unit {
	font-size: 24rpx;
	color: #999999;
}

.product-price-row {
	display: flex;
	align-items: center;
	gap: 10rpx;
}

.product-price {
	font-size: 32rpx;
	font-weight: bold;
	color: #ff6b6b;
}

.select-btn {
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 26rpx;
	padding: 0rpx 30rpx;
	border-radius: 40rpx;
	border: none;
}

.quantity-selector {
	display: flex;
	align-items: center;
	gap: 20rpx;
}

.quantity-btn {
	width: 50rpx;
	height: 50rpx;
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 28rpx;
	border-radius: 50%;
	border: none;
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 0;
}

.quantity-text {
	font-size: 28rpx;
	color: #333333;
	min-width: 40rpx;
	text-align: center;
}

.cart-bar {
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	min-height: 120rpx;
	background-color: #ffffff;
	border-top: 1rpx solid #e5e5e5;
	display: flex;
	align-items: center;
	padding: 0 30rpx;
	padding-bottom: calc(0rpx + env(safe-area-inset-bottom));
	z-index: 100;
}

.cart-icon-wrapper {
	position: relative;
	width: 80rpx;
	height: 80rpx;
	margin-right: 20rpx;
}

.cart-icon {
	width: 80rpx;
	height: 80rpx;
	border-radius: 50%;
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 40rpx;
	display: flex;
	align-items: center;
	justify-content: center;
	font-weight: bold;
}

.cart-badge {
	position: absolute;
	top: -10rpx;
	right: -10rpx;
	background-color: #ff6b6b;
	color: #ffffff;
	font-size: 20rpx;
	min-width: 32rpx;
	height: 32rpx;
	border-radius: 16rpx;
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 0 8rpx;
}

.cart-info {
	flex: 1;
	display: flex;
	flex-direction: column;
}

.cart-total {
	font-size: 36rpx;
	font-weight: bold;
	color: #333333;
	margin-bottom: 4rpx;
}

.cart-tip {
	font-size: 20rpx;
	color: #999999;
}

.submit-btn {
	background-color: #4A90E2;
	color: #ffffff;
	font-size: 32rpx;
	padding: 4rpx 60rpx;
	border-radius: 60rpx;
	border: none;
	font-weight: 500;
}

.fly-ball {
	position: fixed;
	width: 30rpx;
	height: 30rpx;
	background-color: #ff6b6b;
	border-radius: 50%;
	z-index: 9999;
	pointer-events: none;
	transition: all 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
	box-shadow: 0 4rpx 12rpx rgba(255, 107, 107, 0.5);
}
</style>