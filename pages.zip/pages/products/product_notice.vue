<template>
	<view class="notice-container">
		<!-- Banner区域 -->
		<view class="banner-section">
			<image class="banner-image" src="https://yuntuoengine.com/assets_files/liaoning_zongyi/banner_bg.png" mode="widthFix"></image>
		</view>
		
		<!-- 内容区域 -->
		<view class="content-section">
			<view class="product-title">{{ product.name }}</view>
			
			<view class="notice-text">
				<text class="notice-content">{{ noticeText }}</text>
			</view>
			
			<!-- 开始按钮 -->
			<button class="start-btn" @click="startQuestionnaire">开始</button>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			product: {},
			noticeText: ''
		}
	},
	onLoad(options) {
		// 获取产品ID
		const productId = options.id
		if (productId) {
			this.loadProduct(productId)
		}
	},
	methods: {
		loadProduct(productId) {
			// 加载产品数据
			uni.request({
				url: 'https://yuntuoengine.com/assets_files/liaoning_zongyi/data/products.json',
				method: 'GET',
				success: (res) => {
					if (res.data && res.data.categories) {
						// 在所有分类中查找产品
						for (let category of res.data.categories) {
							const product = category.products.find(p => p.id === productId)
							if (product) {
								this.product = product
								this.noticeText = product.notice || ''
								break
							}
						}
					}
				},
				fail: (err) => {
					console.error('加载产品数据失败:', err)
				}
			})
		},
		startQuestionnaire() {
			// 跳转到答题页面
			uni.navigateTo({
				url: `/pages/products/product_questionnaire?id=${this.product.id}`
			})
		}
	}
}
</script>

<style scoped>
.notice-container {
	width: 100%;
	min-height: 100vh;
	background-color: #ffffff;
}

.banner-section {
	width: 100%;
	overflow: hidden;
}

.banner-image {
	width: 100%;
	height: auto;
	display: block;
}

.content-section {
	padding: 40rpx 30rpx;
}

.product-title {
	font-size: 36rpx;
	font-weight: 600;
	color: #333333;
	margin-bottom: 30rpx;
	text-align: center;
}

.notice-text {
	background-color: #f9f9f9;
	border-radius: 16rpx;
	padding: 30rpx;
	margin-bottom: 40rpx;
}

.notice-content {
	font-size: 28rpx;
	color: #666666;
	line-height: 1.8;
	white-space: pre-line;
	display: block;
}

.start-btn {
	width: 100%;
	height: 88rpx;
	background: linear-gradient(135deg, #FFB6C1 0%, #FFC0CB 100%);
	color: dark;
	font-size: 32rpx;
	font-weight: 500;
	border-radius: 44rpx;
	border: none;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 40rpx;
}
</style>

