<template>
    <view class="page">
      <!-- 顶部蓝色状态条 -->
      <view class="top-header">
        <view class="status-main">待下单</view>
        <view class="status-sub">等待下单支付</view>
      </view>
  
      <!-- 白色内容卡片（覆盖在蓝色块上） -->
      <view class="card-wrapper">
        <view class="card">
          <!-- 标题 -->
          <view class="card-title">处方单详情</view>
  
          <!-- 门诊号 -->
          <view class="field-row">
            <text class="field-label">门诊号：</text>
            <text class="field-value">{{ detail.visitNo }}</text>
          </view>
  
          <view class="dash-line"></view>
  
          <!-- 基本信息两列布局 -->
          <view class="info-grid">
            <view class="info-col">
              <text class="info-label">姓名：</text>
              <text class="info-value">{{ detail.name }}</text>
            </view>
            <view class="info-col">
              <text class="info-label">性别：</text>
              <text class="info-value">{{ detail.gender }}</text>
            </view>
  
            <view class="info-col">
              <text class="info-label">年龄：</text>
              <text class="info-value">{{ detail.age }}岁</text>
            </view>
            <view class="info-col">
              <text class="info-label">临床诊断：</text>
              <text class="info-value">{{ detail.diagnosis }}</text>
            </view>
  
            <view class="info-col">
              <text class="info-label">科室：</text>
              <text class="info-value">{{ detail.department }}</text>
            </view>
            <view class="info-col">
              <text class="info-label">开方日期：</text>
              <text class="info-value">{{ formatDate(detail.date) }}</text>
            </view>
          </view>
  
          <view class="dash-line big-space"></view>
  
          <!-- Rp 区域 -->
          <view class="rp-block">
            <text class="rp-title">Rp</text>
            <view class="rp-content">
              <text class="rp-name">{{ detail.formulaName }}</text>
            </view>
  
            <view class="rp-usage">
              <text class="rp-amount">共{{ detail.packCount }}帖（中药饮片方）</text>
              <text class="rp-desc">{{ detail.usage }}</text>
            </view>
          </view>
  
          <view class="dash-line big-space"></view>
  
          <!-- 签名区域 -->
          <view class="sign-row">
            <view class="sign-item">
              <text class="sign-label">医师签名：</text>
              <image
                class="sign-image"
                src="https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_qianming.png"
                mode="heightFix"
              />
            </view>
            <view class="sign-item">
              <text class="sign-label">药师签名：</text>
              <image
                class="sign-image"
                src="https://yuntuoengine.com/assets_files/liaoning_zongyi/zhongyi_qianming.png"
                mode="heightFix"
              />
            </view>
          </view>
        </view>
      </view>
  
      <!-- 底部按钮 -->
      <view class="bottom-bar">
        <button class="bottom-btn" @tap="goBuy">去购药</button>
      </view>
    </view>
  </template>
  
  <script>
  import { 
    STORAGE_KEY_CURRENT_ORDER,
    STORAGE_KEY_USER_REGISTER,
    STORAGE_KEY_PRESCRIPTION_ORDERS
  } from '@/utils/storage.js'
  
  export default {
    name: 'PrescriptionDetail',
    data() {
      return {
        detail: {
          visitNo: '',
          name: '',
          gender: '',
          age: 0,
          diagnosis: '',
          department: '便捷配药门诊',
          date: '',
          formulaName: '',
          packCount: 1,
          usage: '普煎三汁各200mL 自煎（非代煎）\n口服 每日一次',
          pharmacistName: '王某某',
          productPrice: 4.51 // 单价，与商品详情页和复诊详情页保持一致
        }
      }
    },
    onLoad(options) {
      // 从 storage 加载用户信息
      this.loadUserInfo()
      
      // 接收处方单号参数
      if (options.prescriptionNo) {
        this.loadPrescriptionById(options.prescriptionNo)
      }
      
      // 接收处方数据参数（与复诊详情页保持一致）
      if (options.prescription) {
        try {
          const prescriptionData = JSON.parse(decodeURIComponent(options.prescription))
          console.log('接收到的处方数据:', prescriptionData)
          
          // 更新处方信息
          this.detail.visitNo = prescriptionData.id || prescriptionData.visitNo || this.detail.visitNo
          this.detail.formulaName = prescriptionData.details || prescriptionData.medicineName || prescriptionData.formulaName || prescriptionData.name || this.detail.formulaName
          this.detail.packCount = prescriptionData.doses || prescriptionData.quantity || prescriptionData.packCount || this.detail.packCount
          this.detail.productPrice = prescriptionData.productPrice || this.detail.productPrice
          this.detail.name = prescriptionData.patientName || prescriptionData.name || this.detail.name
          // 注意：性别和年龄优先从身份证号识别，只有在没有身份证号时才使用参数中的值
          // 这里先设置参数中的值，但后面会从身份证号重新识别（如果有身份证号）
          this.detail.gender = prescriptionData.patientGender || prescriptionData.gender || this.detail.gender
          this.detail.age = prescriptionData.patientAge || prescriptionData.age || this.detail.age
          this.detail.diagnosis = prescriptionData.diagnosis || this.detail.diagnosis
          this.detail.department = prescriptionData.department || this.detail.department
          const rawDate = prescriptionData.date || prescriptionData.consultationTime || this.detail.date
          this.detail.date = this.formatDate(rawDate) || this.detail.date
        } catch (e) {
          console.error('解析处方数据失败:', e)
        }
      }
      
      // 确保性别和年龄优先从身份证号识别（如果有身份证号）
      // 这样可以覆盖 URL 参数中的性别和年龄，确保身份证号的信息优先级最高
      this.ensureGenderAndAgeFromIdCard()
    },
    methods: {
      // 从身份证号计算年龄
      calculateAgeFromIdCard(idCard) {
        if (!idCard || idCard.length < 15) {
          return 0
        }
        
        let birthDateStr = ''
        // 18位身份证：第7-14位为出生日期 YYYYMMDD
        if (idCard.length === 18) {
          birthDateStr = idCard.substring(6, 14)
        } 
        // 15位身份证：第7-12位为出生日期 YYMMDD，年份前两位需要判断
        else if (idCard.length === 15) {
          const year = idCard.substring(6, 8)
          const month = idCard.substring(8, 10)
          const day = idCard.substring(10, 12)
          // 简单判断：如果年份大于当前年份后两位，则认为是19xx年，否则是20xx年
          const currentYear = new Date().getFullYear() % 100
          const birthYear = parseInt(year) > currentYear ? `19${year}` : `20${year}`
          birthDateStr = `${birthYear}${month}${day}`
        } else {
          return 0
        }
        
        // 解析出生日期
        const birthYear = parseInt(birthDateStr.substring(0, 4))
        const birthMonth = parseInt(birthDateStr.substring(4, 6))
        const birthDay = parseInt(birthDateStr.substring(6, 8))
        
        const birthDate = new Date(birthYear, birthMonth - 1, birthDay)
        const today = new Date()
        
        let age = today.getFullYear() - birthYear
        const monthDiff = today.getMonth() - (birthMonth - 1)
        const dayDiff = today.getDate() - birthDay
        
        // 如果还没过生日，年龄减1
        if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
          age--
        }
        
        return age > 0 ? age : 0
      },
      
      // 从身份证号判断性别
      getGenderFromIdCard(idCard) {
        if (!idCard || idCard.length < 15) {
          return '未知'
        }
        
        let genderCode = ''
        // 18位身份证：倒数第二位为性别码，奇数为男，偶数为女
        if (idCard.length === 18) {
          genderCode = idCard.substring(16, 17)
        } 
        // 15位身份证：最后一位为性别码，奇数为男，偶数为女
        else if (idCard.length === 15) {
          genderCode = idCard.substring(14, 15)
        } else {
          return '未知'
        }
        
        return parseInt(genderCode) % 2 === 1 ? '男' : '女'
      },
      
      // 格式化日期，只显示年月日
      formatDate(dateStr) {
        if (!dateStr) {
          return ''
        }
        
        try {
          // 如果是时间戳（数字）
          if (typeof dateStr === 'number') {
            const date = new Date(dateStr)
            const year = date.getFullYear()
            const month = String(date.getMonth() + 1).padStart(2, '0')
            const day = String(date.getDate()).padStart(2, '0')
            return `${year}-${month}-${day}`
          }
          
          // 如果是字符串
          if (typeof dateStr === 'string') {
            // 处理 ISO 格式：2024-01-01T10:30:00 或 2024-01-01 10:30:00
            const datePart = dateStr.split('T')[0].split(' ')[0]
            // 验证格式是否为 YYYY-MM-DD
            if (/^\d{4}-\d{2}-\d{2}$/.test(datePart)) {
              return datePart
            }
            
            // 尝试解析为日期对象
            const date = new Date(dateStr)
            if (!isNaN(date.getTime())) {
              const year = date.getFullYear()
              const month = String(date.getMonth() + 1).padStart(2, '0')
              const day = String(date.getDate()).padStart(2, '0')
              return `${year}-${month}-${day}`
            }
          }
          
          return dateStr
        } catch (e) {
          console.error('格式化日期失败:', e)
          return dateStr
        }
      },
      
      // 从 storage 加载用户信息
      loadUserInfo() {
        try {
          const userInfo = uni.getStorageSync(STORAGE_KEY_USER_REGISTER)
          if (userInfo) {
            this.detail.name = userInfo.realName || this.detail.name
            
            // 从身份证号计算年龄和性别
            if (userInfo.idNumber) {
              this.detail.age = this.calculateAgeFromIdCard(userInfo.idNumber)
              this.detail.gender = this.getGenderFromIdCard(userInfo.idNumber)
              
              console.log('从 storage 加载用户信息:', {
                name: userInfo.realName,
                idNumber: userInfo.idNumber,
                age: this.detail.age,
                gender: this.detail.gender
              })
            }
          }
        } catch (e) {
          console.error('加载用户信息失败:', e)
        }
      },
      
      // 确保性别和年龄从身份证号识别（优先级最高）
      ensureGenderAndAgeFromIdCard() {
        try {
          const userInfo = uni.getStorageSync(STORAGE_KEY_USER_REGISTER)
          if (userInfo && userInfo.idNumber) {
            // 优先使用身份证号识别的性别和年龄
            const ageFromIdCard = this.calculateAgeFromIdCard(userInfo.idNumber)
            const genderFromIdCard = this.getGenderFromIdCard(userInfo.idNumber)
            
            if (ageFromIdCard > 0) {
              this.detail.age = ageFromIdCard
            }
            if (genderFromIdCard !== '未知') {
              this.detail.gender = genderFromIdCard
            }
            
            console.log('从身份证号重新识别性别和年龄:', {
              idNumber: userInfo.idNumber,
              age: this.detail.age,
              gender: this.detail.gender
            })
          }
        } catch (e) {
          console.error('从身份证号识别性别和年龄失败:', e)
        }
      },
      
      // 根据处方ID从 storage 加载处方信息
      loadPrescriptionById(prescriptionId) {
        try {
          const prescriptionOrders = uni.getStorageSync(STORAGE_KEY_PRESCRIPTION_ORDERS) || []
          const prescription = prescriptionOrders.find(p => p.id === prescriptionId)
          
          if (prescription) {
            this.detail.visitNo = prescription.id || prescription.visitNo || this.detail.visitNo
            this.detail.formulaName = prescription.details || prescription.medicineName || prescription.formulaName || prescription.name || this.detail.formulaName
            this.detail.packCount = prescription.doses || prescription.quantity || prescription.packCount || this.detail.packCount
            this.detail.productPrice = prescription.productPrice || this.detail.productPrice
            this.detail.diagnosis = prescription.diagnosis || this.detail.diagnosis
            this.detail.department = prescription.department || this.detail.department
            const rawDate = prescription.consultationTime || prescription.date || this.detail.date
            this.detail.date = this.formatDate(rawDate) || this.detail.date
          } else {
            // 如果 storage 中没有找到，使用 prescriptionNo 作为 visitNo
            this.detail.visitNo = prescriptionId
            console.warn('未在 storage 中找到处方信息，使用默认值')
          }
        } catch (e) {
          console.error('加载处方信息失败:', e)
          // 如果加载失败，至少设置 visitNo
          this.detail.visitNo = prescriptionId
        }
      },
      
      goBuy() {
        // 验证必要数据
        if (!this.detail.visitNo) {
          uni.showToast({
            title: '处方信息不完整',
            icon: 'none'
          })
          return
        }
        
        // 构建订单信息
        // 使用统一的单价和数量计算总价（与商品详情页和复诊详情页保持一致）
        const unitPrice = this.detail.productPrice || 4.51 // 单价，默认与商品详情页一致
        const quantity = this.detail.packCount || 1
        const totalPrice = parseFloat((unitPrice * quantity).toFixed(2))
        
        const orderItems = [{
          id: this.detail.visitNo,
          name: this.detail.formulaName || '中药处方',
          type: '中药',
          price: totalPrice,
          quantity: quantity
        }]
        
        const medicineCost = parseFloat(orderItems.reduce((sum, item) => sum + item.price, 0).toFixed(2))
        
        const orderInfo = {
          prescriptions: [this.detail.visitNo],
          items: orderItems,
          deliveryInfo: {
            distributor: '辽宁中医药大学附属医院',
            logistics: '顺丰快递',
            purchaseMethod: '药品配送-在线支付',
            shippingPaymentMethod: '在线支付'
          },
          cost: {
            medicineCost: medicineCost,
            isDecocted: false,
            shippingFee: 0 // 确认页面会自动设置为18元
          },
          total: medicineCost // 确认页面会重新计算包含快递费的总价
        }
        
        // 保存订单信息
        try {
          uni.setStorageSync(STORAGE_KEY_CURRENT_ORDER, orderInfo)
          
          // 跳转到订单确认页面
          uni.navigateTo({
            url: '/pages/order/confirm',
            success: () => {
              console.log('跳转到订单确认页面成功')
            },
            fail: (err) => {
              console.error('跳转失败:', err)
              uni.showToast({
                title: '跳转失败，请重试',
                icon: 'none'
              })
            }
          })
        } catch (e) {
          console.error('保存订单信息失败:', e)
          uni.showToast({
            title: '保存订单信息失败',
            icon: 'none'
          })
        }
      }
    }
  }
  </script>
  
  <style scoped lang="scss">
  .page {
    min-height: 100vh;
    background-color: #f7f7f7;
    padding-bottom: 140rpx; // 预留底部按钮空间
    box-sizing: border-box;
  }
  
  /* 顶部蓝色渐变块 */
  .top-header {
    height: 220rpx;
    padding: 40rpx 40rpx 0;
    box-sizing: border-box;
    background: linear-gradient(180deg, #4a8cff, #4aa0ff);
    color: #ffffff;
  }
  
  .status-main {
    font-size: 32rpx;
    font-weight: 600;
  }
  
  .status-sub {
    margin-top: 8rpx;
    font-size: 26rpx;
    opacity: 0.9;
  }
  
  /* 白卡片整体往上“顶”一点，形成悬浮感 */
  .card-wrapper {
    margin-top: -60rpx;
    padding: 0 24rpx;
  }
  
  .card {
    background-color: #ffffff;
    border-radius: 24rpx;
    padding: 40rpx 32rpx 32rpx;
    box-shadow: 0 6rpx 16rpx rgba(0, 0, 0, 0.06);
  }
  
  /* 标题 */
  .card-title {
    text-align: center;
    font-size: 32rpx;
    font-weight: 600;
    color: #333333;
    margin-bottom: 30rpx;
  }
  
  /* 行样式 */
  .field-row {
    display: flex;
    flex-direction: row;
    align-items: center;
    margin-bottom: 18rpx;
  }
  
  .field-label {
    font-size: 26rpx;
    color: #777777;
    width: 140rpx;
  }
  
  .field-value {
    font-size: 28rpx;
    color: #333333;
  }
  
  /* 虚线分割 */
  .dash-line {
    border-bottom: 1px dashed #e0e0e0;
    margin: 18rpx 0;
  }
  
  .big-space {
    margin-top: 40rpx;
  }
  
  /* 两列信息 */
  .info-grid {
    display: flex;
    flex-wrap: wrap;
    margin-top: 10rpx;
  }
  
  .info-col {
    width: 50%;
    flex-direction: row;
    display: flex;
    margin-bottom: 16rpx;
  }
  
  .info-label {
    font-size: 26rpx;
    color: #777777;
  }
  
  .info-value {
    font-size: 28rpx;
    color: #333333;
  }
  
  /* Rp 区域 */
  .rp-block {
    margin-top: 20rpx;
  }
  
  .rp-title {
    font-size: 40rpx;
    font-weight: 600;
    color: #333333;
  }
  
  .rp-content {
    margin-top: 24rpx;
  }
  
  .rp-name {
    font-size: 30rpx;
    color: #333333;
  }
  
  .rp-usage {
    margin-top: 40rpx;
  }
  
  .rp-amount {
    font-size: 30rpx;
    color: #333333;
    margin-bottom: 10rpx;
    display: block;
  }
  
  .rp-desc {
    font-size: 26rpx;
    color: #777777;
    line-height: 1.6;
  }
  
  /* 签名区域 */
  .sign-row {
    margin-top: 40rpx;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
  }
  
  .sign-item {
    flex: 1;
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  
  .sign-label {
    font-size: 26rpx;
    color: #777777;
  }
  
  .sign-image {
    height: 40rpx;
    margin-left: 12rpx;
  }
  
  .sign-text {
    font-size: 26rpx;
    color: #333333;
    margin-left: 12rpx;
  }
  
  /* 底部按钮条 */
  .bottom-bar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 16rpx 40rpx 40rpx;
    box-sizing: border-box;
    background-color: #f7f7f7;
  }
  
  .bottom-btn {
    width: 100%;
    height: 88rpx;
    line-height: 88rpx;
    text-align: center;
    font-size: 30rpx;
    color: #ffffff;
    border-radius: 999rpx;
    background-color: #4a8cff;
    border: none;
  }
  
  .bottom-btn::after {
    border: none;
  }
  </style>
  